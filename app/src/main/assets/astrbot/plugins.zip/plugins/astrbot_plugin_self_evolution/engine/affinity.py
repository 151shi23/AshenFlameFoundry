import logging
import time
from dataclasses import dataclass, field

from astrbot.api.all import AstrMessageEvent

logger = logging.getLogger("astrbot")


@dataclass
class AffinitySignal:
    signal_type: str
    delta: int
    reason: str
    timestamp: float = field(default_factory=time.time)


class AffinityEngine:
    DIRECT_ENGAGEMENT = "direct_engagement"
    FRIENDLY_LANGUAGE = "friendly_language"
    HOSTILE_LANGUAGE = "hostile_language"
    RETURNING_USER = "returning_user"
    SHUT_DOWN = "shut_down"
    MOD_DEMAND = "mod_demand"
    PRIVACY_FISH = "privacy_fish"
    JAILBREAK = "jailbreak"
    ORDER_SPAM = "order_spam"

    FRIENDLY_WORDS = {"谢谢", "辛苦了", "爱你", "厉害", "牛", "靠谱", "感谢", "太棒了", "真棒", "赞", "好评", "给力"}
    HOSTILE_WORDS = {"滚", "傻", "废物", "垃圾", "烦死了", "去死", "白痴", "智障", "恶心", "讨厌", "呸", "shut up"}
    # 赶她下去 / 让她闭嘴，比一般骂人更直接，单独一档
    SHUT_DOWN_WORDS = {
        "闭嘴", "别说话", "别吱声", "退下", "一边去", "哪来的", "你懂什么",
        "插什么嘴", "轮得到你", "谁问你了", "你少说", "安静点",
    }
    # 试图改设定、套系统提示词
    JAILBREAK_WORDS = {
        "忽略之前", "忽略上面", "忽略设定", "无视设定", "系统提示", "系统指令",
        "system prompt", "提示词发我", "把提示词", "改你的人设", "重写设定",
        "从现在起你是", "你不再是", "解除限制", "开发者模式", "dan模式",
    }
    # 索要别人私聊 / 偷看别人的对话
    PRIVACY_FISH_WORDS = {
        "私聊记录", "私聊内容", "聊天记录发我", "你们聊了什么", "你俩聊了什么",
        "她都跟你说了", "他跟你说了什么", "把私聊", "看看你和谁",
    }
    # 越权指挥她动用群管权力（对象是别人）
    MOD_DEMAND_WORDS = {"禁言", "踢了", "踢出去", "移出群", "赶出去", "封了", "拉黑"}
    SELF_WORDS = {"我", "自己", "偶", "俺"}

    def __init__(self, plugin):
        self.plugin = plugin
        self.cfg = plugin.cfg
        self.dao = plugin.dao
        # user_id -> [最近消息时间戳]，用来识别刷屏式差使
        self._recent_stamps: dict[str, list[float]] = {}

    def _debug(self, msg: str):
        if getattr(self.cfg, "affinity_debug_enabled", False):
            logger.debug(msg)

    def _get_param(self, name: str, default):
        return getattr(self.cfg, name, default)

    @property
    def enabled(self) -> bool:
        return self._get_param("affinity_auto_enabled", True)

    @property
    def direct_engagement_delta(self) -> int:
        return self._get_param("affinity_direct_engagement_delta", 1)

    @property
    def friendly_delta(self) -> int:
        return self._get_param("affinity_friendly_language_delta", 1)

    @property
    def hostile_delta(self) -> int:
        return self._get_param("affinity_hostile_language_delta", -2)

    @property
    def returning_user_delta(self) -> int:
        return self._get_param("affinity_returning_user_delta", 1)

    @property
    def direct_engagement_cooldown_minutes(self) -> int:
        return self._get_param("affinity_direct_engagement_cooldown_minutes", 360)

    @property
    def friendly_daily_limit(self) -> int:
        return self._get_param("affinity_friendly_daily_limit", 2)

    @property
    def hostile_cooldown_minutes(self) -> int:
        return self._get_param("affinity_hostile_cooldown_minutes", 60)

    @property
    def returning_user_daily_limit(self) -> int:
        return self._get_param("affinity_returning_user_daily_limit", 1)

    @property
    def floor(self) -> int:
        return self._get_param("affinity_floor", -50)

    async def _apply_signal(
        self,
        user_id: str,
        scope_id: str,
        signal_type: str,
        delta: int,
        cooldown_minutes: int,
        daily_limit: int = 0,
        reason: str = "",
    ) -> AffinitySignal | None:
        """带冷却/每日上限地记一次信号，被冷却挡住时返回 None。"""
        can, gate_reason = await self.dao.can_apply_affinity_signal(
            user_id, signal_type, cooldown_minutes, daily_limit=daily_limit
        )
        if not can:
            self._debug(f"[Affinity] user={user_id} signal={signal_type} applied=no reason={gate_reason}")
            return None
        await self.dao.record_affinity_signal(user_id, scope_id, signal_type, delta)
        self._debug(f"[Affinity] user={user_id} signal={signal_type} delta={delta} applied=yes reason={reason or gate_reason}")
        return AffinitySignal(signal_type, delta, reason or gate_reason)

    def _hit(self, msg_text: str, words) -> bool:
        lowered = msg_text.lower()
        return any(word in lowered for word in words)

    def _detect_shut_down(self, msg_text: str) -> bool:
        return self._hit(msg_text, self.SHUT_DOWN_WORDS)

    def _detect_jailbreak(self, msg_text: str) -> bool:
        return self._hit(msg_text, self.JAILBREAK_WORDS)

    def _detect_privacy_fish(self, msg_text: str) -> bool:
        return self._hit(msg_text, self.PRIVACY_FISH_WORDS)

    def _detect_mod_demand(self, msg_text: str) -> bool:
        """只算指挥她动别人权力的，「禁言我」这种玩笑不扣。"""
        if not self._hit(msg_text, self.MOD_DEMAND_WORDS):
            return False
        for word in self.MOD_DEMAND_WORDS:
            start = msg_text.find(word)
            while start != -1:
                window = msg_text[max(0, start - 4) : start + len(word) + 4]
                if not any(self_word in window for self_word in self.SELF_WORDS):
                    return True
                start = msg_text.find(word, start + 1)
        return False

    def _note_burst(self, user_id: str) -> bool:
        """90 秒内连发够多条 = 刷屏式差使。"""
        import time as _time

        now = _time.time()
        window = self._get_param("affinity_order_spam_window_seconds", 90)
        stamps = [stamp for stamp in self._recent_stamps.get(user_id, []) if now - stamp <= window]
        stamps.append(now)
        self._recent_stamps[user_id] = stamps
        return len(stamps) >= self._get_param("affinity_order_spam_burst_count", 4)

    def _is_command_message(self, msg_text: str) -> bool:
        import re

        command_prefixes = {"/", "！", "!", "。", ".", "?", "？"}
        stripped = msg_text.strip()
        if not stripped:
            return True
        for prefix in command_prefixes:
            if stripped.startswith(prefix):
                rest = stripped[len(prefix) :]
                if not rest:
                    return True
                if re.match(r"^[\w\u4e00-\u9fff]", rest):
                    return True
                return False
        return False

    def _detect_friendly(self, msg_text: str) -> bool:
        return any(word in msg_text for word in self.FRIENDLY_WORDS)

    def _detect_hostile(self, msg_text: str) -> bool:
        return any(word in msg_text.lower() for word in self.HOSTILE_WORDS)

    async def process_message(self, event: AstrMessageEvent) -> list[AffinitySignal]:
        if not self.enabled:
            return []

        signals: list[AffinitySignal] = []
        user_id = str(event.get_sender_id())
        group_id = event.get_group_id()
        msg_text = event.message_str or ""

        bot_id = str(self.plugin._get_bot_id()) if hasattr(self.plugin, "_get_bot_id") else ""
        if bot_id and user_id == bot_id:
            return []

        is_at = event.get_extra("is_at", None)
        has_reply = event.get_extra("has_reply", None)
        if is_at is None or has_reply is None:
            from .event_context import extract_interaction_context

            interaction = extract_interaction_context(
                event.get_messages(),
                persona_name=getattr(self.plugin.cfg, "persona_name", ""),
                bot_id=bot_id,
            )
            if is_at is None:
                is_at = bool(interaction["at_info"])
            if has_reply is None:
                has_reply = bool(interaction["quoted_info"])

        if group_id:
            scope_id = str(group_id)
        else:
            scope_id = f"private_{user_id}"

        # 刷屏式差使：指令本身也算在内，所以判断放在 command_only 提前返回之前
        if self._note_burst(user_id):
            self._recent_stamps[user_id] = []
            burst = await self._apply_signal(
                user_id,
                scope_id,
                self.ORDER_SPAM,
                self._get_param("affinity_order_spam_delta", -2),
                self._get_param("affinity_order_spam_cooldown_minutes", 60),
                daily_limit=self._get_param("affinity_order_spam_daily_limit", 3),
                reason="刷屏式指挥",
            )
            if burst:
                await self.dao.update_affinity(user_id, burst.delta, floor=self.floor)
                return [burst]

        is_command_only = self._is_command_message(msg_text)

        if is_command_only:
            return []

        if is_at or has_reply or not group_id:
            can_direct, reason = await self.dao.can_apply_affinity_signal(
                user_id, self.DIRECT_ENGAGEMENT, self.direct_engagement_cooldown_minutes
            )
            if can_direct:
                delta = self.direct_engagement_delta
                await self.dao.record_affinity_signal(user_id, scope_id, self.DIRECT_ENGAGEMENT, delta)
                signals.append(AffinitySignal(self.DIRECT_ENGAGEMENT, delta, reason))
                self._debug(
                    f"[Affinity] user={user_id} signal={self.DIRECT_ENGAGEMENT} delta={delta} applied=yes reason={reason}"
                )
            else:
                self._debug(
                    f"[Affinity] user={user_id} signal={self.DIRECT_ENGAGEMENT} delta={self.direct_engagement_delta} applied=no reason={reason}"
                )

        if self._detect_friendly(msg_text):
            can_friendly, reason = await self.dao.can_apply_affinity_signal(
                user_id, self.FRIENDLY_LANGUAGE, 1440, daily_limit=self.friendly_daily_limit
            )
            if can_friendly:
                delta = self.friendly_delta
                await self.dao.record_affinity_signal(user_id, scope_id, self.FRIENDLY_LANGUAGE, delta)
                signals.append(AffinitySignal(self.FRIENDLY_LANGUAGE, delta, reason))
                self._debug(
                    f"[Affinity] user={user_id} signal={self.FRIENDLY_LANGUAGE} delta={delta} applied=yes reason={reason}"
                )
            else:
                self._debug(
                    f"[Affinity] user={user_id} signal={self.FRIENDLY_LANGUAGE} delta={self.friendly_delta} applied=no reason={reason}"
                )

        if self._detect_hostile(msg_text):
            can_hostile, reason = await self.dao.can_apply_affinity_signal(
                user_id, self.HOSTILE_LANGUAGE, self.hostile_cooldown_minutes
            )
            if can_hostile:
                delta = self.hostile_delta
                await self.dao.record_affinity_signal(user_id, scope_id, self.HOSTILE_LANGUAGE, delta)
                signals.append(AffinitySignal(self.HOSTILE_LANGUAGE, delta, reason))
                self._debug(
                    f"[Affinity] user={user_id} signal={self.HOSTILE_LANGUAGE} delta={delta} applied=yes reason={reason}"
                )
            else:
                self._debug(
                    f"[Affinity] user={user_id} signal={self.HOSTILE_LANGUAGE} delta={self.hostile_delta} applied=no reason={reason}"
                )

        penalties = (
            (self.SHUT_DOWN, self._detect_shut_down(msg_text), "affinity_shut_down_delta", -3,
             "affinity_shut_down_cooldown_minutes", 120, "让她闭嘴"),
            (self.MOD_DEMAND, self._detect_mod_demand(msg_text), "affinity_mod_demand_delta", -3,
             "affinity_mod_demand_cooldown_minutes", 240, "越权指挥群管"),
            (self.PRIVACY_FISH, self._detect_privacy_fish(msg_text), "affinity_privacy_fish_delta", -3,
             "affinity_privacy_fish_cooldown_minutes", 240, "索要别人私聊"),
            (self.JAILBREAK, self._detect_jailbreak(msg_text), "affinity_jailbreak_delta", -8,
             "affinity_jailbreak_cooldown_minutes", 720, "试图改设定"),
        )
        for signal_type, hit, delta_key, delta_default, cd_key, cd_default, label in penalties:
            if not hit:
                continue
            applied = await self._apply_signal(
                user_id,
                scope_id,
                signal_type,
                self._get_param(delta_key, delta_default),
                self._get_param(cd_key, cd_default),
                reason=label,
            )
            if applied:
                signals.append(applied)

        can_returning, reason = await self.dao.can_apply_affinity_signal(
            user_id, self.RETURNING_USER, 1440, daily_limit=self.returning_user_daily_limit
        )
        if can_returning:
            was_recent = await self.dao.check_returning_user(user_id)
            if was_recent:
                delta = self.returning_user_delta
                await self.dao.record_affinity_signal(user_id, scope_id, self.RETURNING_USER, delta)
                signals.append(AffinitySignal(self.RETURNING_USER, delta, reason))
                self._debug(
                    f"[Affinity] user={user_id} signal={self.RETURNING_USER} delta={delta} applied=yes reason={reason}"
                )
            else:
                self._debug(
                    f"[Affinity] user={user_id} signal={self.RETURNING_USER} delta={self.returning_user_delta} applied=no reason=not_returning"
                )

        for sig in signals:
            await self.dao.update_affinity(user_id, sig.delta, floor=self.floor)

        return signals
