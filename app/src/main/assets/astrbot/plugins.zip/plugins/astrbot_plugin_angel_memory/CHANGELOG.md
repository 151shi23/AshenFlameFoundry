# Changelog

All notable changes to this plugin will be documented in this file.

## [1.6.14] - 2026-09-10

### Features
- `feat(memory)`: 反思与睡眠整理发给小模型的请求里，每次都完全相同的固定说明与本次数据分开提交，固定说明可被提示词缓存命中，减少重复计费与等待。
- `feat(webui)`: 过程追踪记录只显示用户提示词，系统提示词不再出现在页面上；提示词与模型返回都支持「渲染 / 原文」两种查看方式，提示词按排版渲染、模型返回按结构展开，记录不再折叠。

## [1.6.13] - 2026-09-10

### Fixed
- `fix(retrieval)`: 删除记忆后，关键词检索索引里仍残留这条记忆，被删掉的记忆会一直留在检索候选池中；现在删除会同步清理索引（该问题自 2026-02-22 的检索重构起存在）。

### Core Changes
- `chore(memory)`: 启动不再每次全量重建检索索引，索引格式一致时直接复用、格式升级时自动重建一次；升级到本版本后首次启动会重建一次索引。

## [1.6.12] - 2026-09-10

### Features
- `feat(memory)`: 强度归零的记忆不再直接删除，改为先交一次独立审查裁决——判留的升级为永久记忆（此后不再衰减、不会被自动清理），判删的才真正删除，模型没给出结论的一律原样保留；审查本身失败时整批跳过，一条都不删，等下一次睡眠重来。
- `feat(memory)`: 睡眠整理与反思链路解耦，改为每天凌晨 4 点独立执行一次，不再依赖消息触发；进程在 4 点未运行时当天不补跑，配置项 `memory_behavior.sleep_interval` 已移除。
- `feat(webui)`: 总览页「反思归纳记录」升级为「过程追踪记录」，反思与睡眠都落盘保存、重启插件不丢失、永不自动清理，可勾选后手动删除；睡眠记录附带候选数、判删数、判留数与审查耗时，便于观察保留比例。

## [1.6.7] - 2026-09-02

### Features
- `feat(webui)`: 功能调试卡重排探针同步重排预算（`rerank_max_docs` / `rerank_max_tokens_per_doc` 单次覆盖，默认 64 / 1024，兼容全局配置），`POST /debug/rerank` 按 `token_utils(0.25/0.48)` 执行 `docs` 限流与单段 `1024` 截断并回透 `original_docs/kept_docs/doc_truncated/query_truncated`，与主链路 `Hybrid/NoteChunkSearch` 保持一致；前端 `DebugView.vue` 新增两输入并展示截断统计，产物重建至 `pages/memory-dashboard/assets/index-C842LgMg.js`。

## [1.6.6] - 2026-09-02

### Features
- `feat(retrieval)`: 新增重排预算 `retrieval.rerank_max_docs` 默认 64（1-200）与 `retrieval.rerank_max_tokens_per_doc` 默认 1024（128-8192），在 `HybridRetrievalEngine` 与 `NoteChunkSearchEngine` 重排入口按 BM25 顺序截断候选并按 `token_utils` 单段截断（bge-reranker-v2-m3 硬上限 8192/对，推荐 1024），解决 `docs=243` 2s 超时问题。
- `fix(token)`: `llm_memory/utils/token_utils.py` 轻量估算系数由 `0.3/0.6` 校准为 `0.25/0.48`（对齐 deepseek-harness `CHARS_PER_TOKEN=4` 与 README 实测 2946 token），`count_tokens` 误差由 +27% 收敛至 +3.6% 偏保守。
- `fix(retrieval)`: 重排 `provider=unknown` 改为类名兜底透出，`query_len` 按截断后统计，`docs` 截断与单段截断均有 DEBUG 日志。

## [1.6.5] - 2026-09-02

### Fixed
- `fix(retrieval)`: 重排日志补全详细上下文（`provider`/`timeout`/`elapsed`/`docs`/`query_len`）与异常堆栈，区分超时与业务异常，便于定位“永远超时/不够 5 秒”问题。
- `fix(retrieval)`: `HybridRetrievalEngine` 与 `NoteChunkSearchEngine` 同步/异步两条重排路径均记录耗时与降级原因。

## [1.6.4] - 2026-09-02

### Features
- `feat(webui)`: 新增“功能调试”页面（`webui/src/views/DebugView.vue`，路由 `/debug`），提供嵌入与重排探针，支持自定义批次（仅下限 1，无上限，>200 二次确认）与超时（5-120 秒），仅对本次请求生效，便于探测供应商上限；后端新增 `web_api/debug_api.py`（`POST /debug/embedding` 与 `POST /debug/rerank`），整体探针预算 90 秒，单批超时与 413/429 错误分类透出。
- `fix(doc)`: 更新 WebUI 构建产物至 `pages/memory-dashboard/`（`index-Tiyy-A3O.js`）。

## [1.6.3] - 2026-09-02

### Features
- `feat(retrieval)`: 新增向量请求批次大小 `retrieval.embedding_batch_size`（默认 50，仅下限 1，不设上限）与超时 `retrieval.embedding_timeout`（默认 5s，范围 5-120s，仅用于搜索/重排）；写入链路批量向量化默认 60s（`APIEmbeddingProvider` 固定，不走该配置），支持 `AsyncOpenAI` 重建与 `wait_for` 双层超时分流；批次超限触发 413 时自动减半重试。
- `fix(retrieval)`: 搜索链路（`FaissTextIndex` / `SqliteTextIndex` / `FaissVectorStore` / `SqliteVectorStore`）查询与重排超时由硬编码 3s 提升为可配置，默认 5s，由 `retrieval.embedding_timeout` 驱动（`ComponentFactory` 注入，经 `search_timeout`/`rerank_timeout` 分发），超时自动降级为融合/BM25 排序。

## [1.5.1] - 2026-08-07

### Fixed
- `fix(webui)`: 修复管理面板样式全崩——迁移 Naive UI 后全部视图未显式导入组件，模板组件被当未知元素渲染；已补全 App.vue 与 9 个视图的显式组件导入，前端资源已重新构建至 `pages/memory-dashboard`。

## [1.5.0] - 2026-08-07

### Highlights
- WebUI 管理面板从 Vuetify 3 重构为 Naive UI，与 angel_heart、angel_smile 插件统一视觉与交互风格。
- 布局采用左侧可折叠导航 + 主内容区两段式，深色主题，图标统一为 lucide。

### Core Changes
- `refactor(webui)`: 全部 9 个视图迁移至 Naive UI（总览 / 记忆浏览 / 用户画像 / Tags 调试 / 向量检索 / 笔记索引 / 笔记读取 / 导入导出 / 维护状态）。
- `refactor(webui)`: 服务端分页表格迁移为 `n-data-table` remote 模式（记忆浏览 / 向量浏览 / 笔记索引）；客户端表格迁移为本地分页。
- `refactor(webui)`: 详情与删除确认对话框迁移为 `n-modal`；删除操作保留确认弹窗。
- `refactor(webui)`: 移除 Vuetify / mdi 图标依赖，切换为 naive-ui + @iconify/vue + lucide。
- `refactor(webui)`: 抽取公共 `utils/format.ts`（时间戳格式化 / tags 解析 / 文件大小），消除 4 个视图的重复实现。
- `chore(webui)`: 前端资源已重新构建至 `pages/memory-dashboard`。

## [1.4.9] - 2026-05-29

### Highlights
- 笔记系统全面升级为「切片 SQLite + Tantivy CJK bigram」检索架构，替换旧的 `notes_index` 向量集合与标签检索链路。
- 记忆 BM25 分词从 jieba 切换为 CJK 1~2-gram，记忆向量+BM25 融合算法改为 RRF（Reciprocal Rank Fusion，K=60）。
- LLM 工具统一更名为 `angel_remember` / `angel_recall` / `angel_note_read` / `angel_note_create`。

### Core Changes
- `feat(notes)`: 新增段落级笔记切片器，采用路径第 0 行、空行边界切片，并保持代码块与表格完整。
- `feat(notes)`: 新增独立切片存储 `note_chunks.db`，与记忆库分离，支持随时全量重建。
- `feat(notes)`: 新增 Tantivy 多级搜索引擎，使用 CJK 1~2-gram，优先执行 2-gram AND，结果不足时降级为 1+2-gram OR。
- `feat(notes)`: 笔记搜索支持多词查询（空格 / `|` 分隔），按命中词数与 BM25 分数排序，并按文件聚合结果。
- `refactor(notes)`: `angel_note_read` 改为 `offset + limit` 分页读取，默认最大 3 万字符，并返回 `has_more` 提示。
- `refactor(notes)`: `angel_recall` 统一检索记忆与笔记，笔记结果聚合到文件级并执行精准后过滤。
- `refactor(memory)`: 记忆 BM25 检索同步升级为 CJK bigram 分词，移除 jieba 运行依赖。
- `refactor(memory)`: 记忆向量+BM25 融合切换为 RRF；RRF 分数按相对排名截断，不再套用 0.5 绝对相似度阈值。
- `refactor(config)`: 笔记配置合并到 `note_assistant` 组，`top_k` 默认改为 3。
- `refactor(startup)`: 启动时按索引版本触发切片索引重建，旧文件索引版本直接失效，避免架构升级后残留旧状态。
- `refactor(webui)`: 调试页面改为切片检索视图，展示内容摘要、分数与行号；前端资源已重新构建。
- `chore(cleanup)`: 清理旧笔记向量链路、`notes_index` 同步任务、旧标签检索路径与不再使用的 parser/tag 管理代码。

## [1.3.40] - 2026-05-29

### Highlights
- 新增 `note_create` 笔记工具：AI 可在学习或交流中自主整理并归档 Markdown 笔记，写入后立即纳入知识库索引。
- 移除研究子代理（`transfer_to_researcher` / Handoff）相关能力，自主学习能力由笔记工具承接。
- 配置项 `research_assistant` 改名为 `note_assistant`，仅保留「检索笔记」与「生成笔记」两个开关。

### Core Changes
- `feat(tools)`: 新增 `tools/note_create.py`，写入笔记后主动调用 `note_service.parse_and_store_file_sync` 同步索引。
- `feat(config)`: 新增 `note_assistant.enable_recall`（增强检索是否检索笔记）与 `note_assistant.enable_create`（是否注册 note_create 工具）。
- `refactor(retrieval)`: 检索服务按 `enable_recall` 短路笔记检索与笔记 query 预处理。
- `chore(cleanup)`: 删除 `tools/research_subagent.py`、`tools/research_fellow_prompt.md` 及对应测试，移除 `main.py` 中研究子代理注册逻辑。

## [1.3.37] - 2026-05-27

### Highlights
- 新增内置 WebUI 管理面板（基于 AstrBot Plugin Pages），无需额外启动服务即可在 AstrBot 后台管理记忆系统。
- 移除旧的 `debug_tool/`（Streamlit），所有功能已迁移至内置管理面板。

### Core Changes
- `feat(webui)`: 新增 `web_api/` 后端模块，通过 `register_web_api` 注册 16 个管理 API 路由。
- `feat(webui)`: 新增 `pages/memory-dashboard/` 前端（Vue 3 + Vuetify 3），包含 9 个管理页面。
- `feat(webui)`: 用户画像页直接复用 `llm_memory.utils.user_profile` 的识别逻辑，确保与运行时行为一致。
- `refactor(debug)`: 移除 `debug_tool/` 目录及其独立依赖。

### WebUI 管理面板功能
- 📌 总览：系统状态、提供商信息、统计数据
- 🧾 记忆浏览：分页、搜索、按 scope 过滤、删除
- 👤 用户画像：识别所有用户、按属性分组展示画像记忆
- 🔖 Tags 调试：标签命中搜索、全局标签列表
- 🧭 向量检索：memory_index / notes_index 向量查询与浏览
- 🗂️ 笔记索引：分页浏览笔记索引记录
- 📝 笔记读取：按 note_short_id + 行范围模拟读取
- 🔄 导入导出：JSON 快照导出与导入
- 🛠️ 维护状态：查看维护状态、下载备份文件

## [1.3.14] - 2026-05-02

### Bug Fixes
- `fix(parser)`: 修复 `UniversalParser.SUPPORTED_EXTENSIONS` 在移除 MarkItDown 后残留的缩进错误。

### Core Changes
- `refactor(memory)`: 清理 DeepMind 中已不走主流程的旧反馈服务封装。
- `refactor(memory)`: 移除会话短期仓里废弃的生命值扣减路径，统一描述为会话工作记忆缓存。
- `refactor(recall)`: 清理旧双轨召回命名，`comprehensive_recall` 统一使用 `limit`，不再暴露 `fresh/consolidated` 语义。
- `refactor(recall)`: 移除链式召回中无效的 `memory_handlers` 传递，并让 `final_limit` 真正限制最终返回数量。

## [1.3.13] - 2026-05-02

### Highlights
- 研究助手接入上游 SubAgent / Handoff 机制，启动时注册 `transfer_to_researcher` 子代理工具。
- 移除旧的 `research_topic` 工具入口，研究任务统一走上游委派执行链路。

### Core Changes
- `refactor(research)`: 新增 `research_subagent` 注册辅助模块，复用 `research_fellow_prompt.md` 与 `research_assistant.provider_id` / `persona_id` 配置。
- `refactor(research)`: 移除手写 `ResearchTool.run()` 与插件内直接 `tool_loop_agent()` 调用。
- `chore(config)`: 配置页移除旧研究启动提示 `start_messages`，避免展示已不再生效的行为。

## [1.3.12] - 2026-05-02

### Highlights
- 使用 FAISS 自建轻量向量索引替换 ChromaDB 运行依赖，记忆与笔记向量层改为 provider 专用 sidecar index。
- 启动时自动检查 SQL 真相层与当前 provider 的 FAISS 向量层一致性，缺失补写、孤儿清理、文本变化重写，必要时重建。
- 调试工具改为直接读取 FAISS `memory_index` / `notes_index`，支持 sidecar 浏览、统计和向量查询。

### Core Changes
- `feat(vector)`: 新增 `FaissVectorStore` / `FaissTextIndex`，使用 `IndexFlatIP + IndexIDMap` 与显式 L2 normalize。
- `refactor(vector)`: `VectorStore` 保留兼容名称，底层切换为 FAISS，不再导入或初始化 ChromaDB。
- `refactor(startup)`: 组件初始化阶段执行 FAISS 启动一致性检查，日志输出真相层条数、向量层条数、缺失、孤儿、文本变化、写入、删除与重建状态。
- `refactor(debug-tool)`: 调试工具移除 ChromaDB 依赖，向量页改为读取 FAISS sidecar SQLite 与 FAISS index。
- `chore(deps)`: `requirements.txt` / `debug_tool/requirements.txt` 移除 `chromadb`，新增 `faiss-cpu` 与 `numpy`。

### Tests
- `feat(test)`: 新增 FAISS 单元测试，覆盖 upsert/search/delete/reload、provider 隔离、模型变化清空旧向量空间、SQL 真相层一致性同步。
- `chore(test)`: 新增 `pytest.ini`，正式单测仅收集 `tests/`，避免 `debug_tool` 脚本式模拟测试被 pytest 误收集。

## [1.3.11] - 2026-04-30

### Highlights
- 修复调试工具向量库路径中的 provider ID 非法字符处理不一致问题。
- 增强调试工具对 ChromaDB 版本差异的兼容性，API 读取失败时可回退到 SQLite 直读集合信息。
- 优化记忆时间字段处理，保留并安全解析原始 `created_at`，记忆展示增加相对时间提示。

### Bug Fixes
- `fix(debug-tool)`: `debug_tool` 的向量库路径生成与主插件路径清洗规则对齐。
- `fix(debug-tool)`: ChromaDB 集合列表、统计与浏览在 API 不兼容时回退读取 `chroma.sqlite3`。
- `fix(memory)`: 会话短期记忆创建时不再无条件覆盖原始 `created_at`。

### Core Changes
- `refactor(recall)`: 检索结果补充时间衰减重排，主动记忆不参与时间衰减。
- `refactor(memory)`: 合并记忆构建过程补全 `created_at`、`useful_count`、`useful_score`、`last_recalled_at` 等元数据。

## [1.3.10] - 2026-04-13

### Highlights
- 移除 `markitdown[all]` 依赖，修复 onnxruntime 版本冲突导致的用户安装失败问题。
- 插件现仅支持 Markdown 和 TXT 格式文件解析，其他格式（PDF/DOCX/PPTX 等）不再支持。

### Core Changes
- `chore(deps)`: 从 `requirements.txt` 和 `debug_tool/requirements.txt` 中移除 `markitdown[all]>=0.1.0`。
- `refactor(parser)`: `universal_parser.py` 注释掉所有 markitdown 导入、初始化与文件转换代码，`SUPPORTED_EXTENSIONS` 仅保留 `.md`、`.txt`。
- `refactor(parser)`: `parser_manager.py` 更新相关注释。

### Notes
- 如需启用文档转换功能，请自行安装 `markitdown[all]`，并参考 `universal_parser.py` 中注释的代码手动恢复。

## [1.3.9] - 2026-03-22

### Highlights
- 修复 `system_context` 注入策略：仅在拿不到天使之心 `secretary_decision` 时，才使用 `_no_save` 注入，避免历史污染与行为回归。

### Bug Fixes
- `fix(injection)`: `DeepMind` 新增 `has_secretary_decision` 标志并传递到注入服务。
- `fix(injection)`: `DeepMindInjectionService` 按标志分流注入路径。
- `fix(injection)`: 有决策时走 `extra_user_content_parts(TextPart)`；无决策时走 `request.contexts` 且 `_no_save=True`。

## [1.3.8] - 2026-03-21

### Highlights
- 优化新记忆 `tags` 规则，要求按知识图谱节点拆分为简短实体词、关系词、属性词，并明确用户昵称与 `uid` 需分别入 tag。

### Core Changes
- `refactor(prompt)`: `memory_system_guide_async.md` 收紧 `tags` 生成规则，明确使用简短图谱节点，并以 `["小明", "123456", "喜好", "咖啡"]` 作为正确示例。

## [1.3.7] - 2026-03-21

### Highlights
- 优化反思整理提示词中的用户身份表达，聊天记录与论断生成统一强调“昵称（ID）”格式，降低同名用户混淆。

### Core Changes
- `refactor(prompt)`: 反思上下文中的用户展示格式由 `昵称/uid` 调整为 `昵称（uid）`，与记忆论断规范保持一致。
- `refactor(prompt)`: `memory_system_guide_async.md` 新增用户身份书写规则，要求 `judgment` 涉及具体用户时准确同时使用昵称和 ID，例如 `小明（123456）`。

## [1.3.4] - 2026-03-20

### Highlights
- 修复调试工具读取 embedding provider 与运行时配置不一致的问题，减少配置排查时的误导。
- 调试侧栏新增 provider 回退告警，便于直接识别“配置值”和“实际使用值”是否偏离。

### Bug Fixes
- `fix(debug-tool)`: `debug_tool` 现在优先读取插件配置 `retrieval.embedding_provider_id`，再回退到首个可用 embedding provider。
- `feat(observability)`: 新增 provider 状态信息与回退警告展示，帮助定位 provider 未启用或配置缺失问题。

## [1.3.3] - 2026-03-17

### Highlights
- 优化人格解析逻辑，完全委托给 `persona_manager.resolve_selected_persona`，与 AstrBot 主链路保持一致。
- 简化人格解析路径，移除旧的 `conversation_manager` 回读逻辑，直接从事件读取 `conversation.persona_id`。
- 增强 `provider_settings` 类型检查，缺失或非法时记录警告日志并使用空配置兜底。

### Core Changes
- `refactor(persona)`: `get_event_persona_name` 方法完全重构，统一使用 `resolve_selected_persona` 解析人格。
- `feat(config)`: `get_config` 方法新增 `umo` 参数支持，可获取会话级别的运行时配置。
- `fix(safety)`: 修复 `get_config` 中 `getter` 变量可能未定义的问题。

### Thanks
- 感谢 @lubuoren 提交的 PR #27，优化了 persona 解析逻辑。

## [1.3.2] - 2026-03-16

### Highlights
- 修复人格名称来源，改为基于当前消息事件解析生效人格，不再依赖 `angel_heart` 的 `secretary_decision` 字段。
- 记忆域解析与反思链路同步使用事件人格，降低多人格会话下误落入 `public` 的概率。

### Bug Fixes
- `fix(scope)`: 人格获取逻辑从外部决策字段迁移到事件侧解析，修复 `conversation_scope_map` 人格键命中不稳定问题。

## [1.2.9] - 2026-03-09

### Highlights
- 修复记忆合并后向量索引丢失的问题，合并记忆现在可被向量检索正确命中。
- 公开 `build_vector_text` 方法，消除跨层调用私有方法的代码异味。

### Bug Fixes
- `fix(vector)`: 合并记忆后新增向量 upsert，修复合并记忆无法被向量检索命中的问题。
- `fix(style)`: `memory_vector_sync_service.py` 末尾补充缺失的换行符。

### Refactor
- `refactor(api)`: `_build_vector_text` → `build_vector_text`，公开为正式 API，更新所有调用点。

## [1.2.6] - 2026-02-22

### Highlights
- 反思链路从 `AstrMessageEvent` 解耦为纯数据输入，便于测试与审查。
- 反思调度日志细化，覆盖入缓冲、触发判定、tick 扫描、执行完成与失败回滚。

### Core Changes
- `refactor(reflection)`: 新增 `ReflectionInput` 数据载体，反思执行入口改为 DTO 参数，不再依赖事件对象重建。
- `refactor(reflection)`: 会话反思状态缓存改为持有 `latest_input`，移除反思路径中的事件/响应序列化依赖。
- `feat(logging)`: 新增 `[反思调度]` / `[反思执行]` 关键日志，输出触发原因、会话、累计轮次、记录数、执行结果与回滚状态。

## [1.2.5] - 2026-02-22

### Highlights
- 检索策略进一步收敛为“能力分档”：重排能力与嵌入能力解耦，支持 BM25-only + 重排。
- 记忆反思提示词精简为强规则版本，并移除 task 记忆生成要求。
- 新增验收白名单，阻止 task 类型新记忆进入入库链路。

### Core Changes
- `refactor(retrieval)`: `HybridRetrievalEngine` 调整为先 BM25 候选，再按向量/重排能力组合策略。
- `fix(retrieval)`: 重排失败自动降级到无重排策略（有向量降级融合，无向量降级 BM25）。
- `feat(test)`: 增加混合检索模拟测试覆盖重排失败降级路径。
- `refactor(prompt)`: `memory_system_guide_async.md` 改为精简强规则版，并删除 task 记忆要求。
- `fix(validation)`: `MemoryIDResolver.normalize_new_memories_format` 增加类型白名单，仅允许 `knowledge/skill/emotional/event`。
- `refactor(config)`: 调整向量化检索配置文案与顺序，强调“向量非必须、重排推荐”。

## [1.2.4] - 2026-02-22

### Highlights
- 移除“简化记忆模式”配置开关，检索模式改为按能力自动分档。
- 新增“向量化检索”配置分组，集中管理嵌入与重排相关项。

### Core Changes
- `refactor(config)`: 删除 `enable_simple_memory` 配置入口与对应代码分支。
- `feat(config)`: 新增 `retrieval` 分组（`embedding_provider_id` / `enable_local_embedding` / `rerank_provider_id`）。
- `feat(runtime)`: 无向量能力时自动进入 BM25-only；有向量/重排能力时自动升级到融合或重排策略。
- `refactor(maintenance)`: 睡眠维护中与 simple 模式相关的判定改为能力判定（BM25-only / vector）。

## [1.2.3] - 2026-02-22

### Highlights
- 检索层重构为 Tantivy BM25，实现中文 `jieba` 预分词 + BM25 检索主链路。
- 新增三档检索策略：BM25 直出、向量融合、向量+BM25 候选混合重排。
- SimpleMemoryRuntime 路径接入 rerank_provider，不再与 Vector 路径能力割裂。

### Core Changes
- `refactor(retrieval)`: `llm_memory/components/bm25_retriever.py` 改为 Tantivy 检索实现，并保留模块引用路径。
- `feat(retrieval)`: BM25 分数按最大值归一到 `[0,1]`，融合公式固定为 `0.7*vector + 0.3*bm25`。
- `feat(retrieval)`: 在 `memory_sql_manager` 中实现三档策略调度与重排候选合并去重。
- `feat(simple-runtime)`: `ComponentFactory` 创建 `MemorySqlManager` 时注入 `rerank_provider`。
- `refactor(maintenance)`: 移除睡眠维护中的 FTS5 一致性巡检任务。
- `chore(deps)`: 新增依赖 `tantivy>=0.22.0`。

## [1.2.2] - 2026-02-20

### Highlights
- 统一笔记展开工具的代码命名，避免“文件/类名与工具名不一致”造成维护误导。

### Core Changes
- `refactor(tooling)`: `tools/expand_note_context.py` 重命名为 `tools/note_recall.py`。
- `refactor(tooling)`: 工具类 `ExpandNoteContextTool` 重命名为 `NoteRecallTool`。
- `refactor(tooling)`: `main.py` 同步更新导入与注册日志文案，保持对外工具名 `note_recall` 与代码命名一致。

## [1.2.1] - 2026-02-20

### Highlights
- 修复插件卸载阶段异步任务清理不完整问题，避免出现 pending task 销毁与协程未等待风险。

### Core Changes
- `fix(shutdown)`: `PluginManager.shutdown()` 与 `BackgroundInitializer.shutdown()` 调整为异步关闭链路，统一执行任务取消与等待收束。
- `fix(shutdown)`: `AngelMemoryPlugin` 追踪 `after_message_sent` 创建的后台任务，并在 `terminate()` 中先取消并等待，再关闭组件。
- `fix(stability)`: 增加关闭流程幂等保护，避免重复关闭导致状态混乱。

## [1.2.0] - 2026-02-20

### Highlights
- 重启并落地 FTS5 混合检索链路，替代旧关键词子串匹配主路径。
- 记忆与笔记索引彻底分离（同库分表），统一融合算法并支持真实向量分接入。
- 检索稳定性与可观测性增强：启动预构建、索引体积日志、一致性巡检与自动修复。
- 清理历史遗留：移除废弃笔记向量接口与 FlashRank 残留文案/命名。

### Core Changes
- `feat(retrieval)`: 新增 `FTS5HybridRetriever`，采用 `jieba` 预分词 + FTS5 (`unicode61`) 检索。
- `feat(retrieval)`: 记忆检索支持 `tags > judgment` 权重（`bm25(memory_fts, 2.0, 1.0)`）。
- `feat(retrieval)`: 笔记检索切换为纯 tags 索引（`note_fts`），不索引正文。
- `feat(fusion)`: 融合公式统一为 `final = fts_weight * fts_score + vector_weight * vector_score`。
- `feat(fusion)`: 向量模式主链路接入真实 `vector_scores`（记忆/笔记）；向量缺失时保留占位分降级。
- `feat(stability)`: 增加 FTS 初始化线程安全保护（原子重建 + 失败日志 + 状态回滚）。
- `feat(observability)`: 新增 `[FTS5重建]` 索引规模日志（memory_fts/note_fts 行数与 DB 大小）。
- `feat(maintenance)`: 新增 FTS 与 SQL 一致性巡检及自动修复，并接入睡眠维护任务。
- `perf(sync)`: 批量场景改为增量同步优先，减少不必要的全量重建。
- `refactor(cleanup)`: 删除 `vector_store` 中废弃旧笔记接口（仅抛异常的历史方法）。
- `refactor(cleanup)`: 清理 `vector_store.py` 与 `README.md` 中 FlashRank 历史残留。
- `fix(safety)`: `note_service` 增加 `similarity` 安全转换，规避 `None`/非数值类型异常。
- `fix(safety)`: FTS MATCH 构造改进，token 采用字面量安全拼接；`clear_index` 增加 target 严格校验。

### Notes
- 本版本为检索架构升级版本（minor），语义与行为有明显变更，按 `1.2.0` 发布。
- 建议升级后重点关注：top-K 命中率、召回率、融合分分布与 FTS 巡检日志。

## [1.1.0] - 2026-02-20

### Highlights
- 实现三档自适应记忆衰减算法（TMD），让记忆系统具备真正的遗忘能力。
- 记忆按使用价值自动分为易逝档（T0）、待证档（T1）、核心档（T2），各档施加不同遗忘策略。
- 噪声记忆自然清退，经过验证的重要记忆永久保留，年驱散率稳定在 ~95%。
- 遗忘参数支持用户自定义覆盖，默认参数经仿真验证可直接使用。

### Core Changes
- `feat(decay)`: 新增 `MemoryDecayPolicy` 与 `MemoryDecayConfig`，实现三档分级遗忘策略。
- `feat(decay)`: 记忆模型新增 `useful_count`、`useful_score`、`last_recalled_at`、`last_decay_at` 字段，支持价值累积与衰减追踪。
- `feat(decay)`: 反馈链路新增 `recalled_memory_ids` 参数，区分"被召回且有用"与"被召回但无用"两种信号。
- `feat(decay)`: T0 自然衰减采用单条 CTE SQL 批量执行，避免逐行 IO。
- `refactor(feedback)`: 移除召回阶段的即时衰减逻辑，衰减统一收归反馈阶段与睡眠周期。
- `refactor(reinforce)`: 强化增量从 3 调整为 1，配合 `useful_score` 升档机制重新平衡。
- `fix(merge)`: 记忆合并时保留最高 `useful_score`，防止合并导致降档。
- `feat(config)`: 新增 `decay_policy_override` 配置项，支持用户覆盖遗忘参数。
- `feat(compat)`: 数据库在线迁移，自动补充新字段，兼容已有数据。

### Notes
- 已有记忆升级后 `useful_score` 初始为 0（T0 档），需通过后续召回反馈重新积累价值。
- 遗忘参数默认值经过多压力等级仿真验证（500~10,000 次/天），一般场景无需修改。
- 详见 `docs/tiered_memory_decay_paper.md` 获取完整的算法论文与仿真数据。

## [1.0.0] - 2026-02-20

### Highlights
- 重构整体数据结构，建立中央索引作为真相源。
- 向量库职责收敛为向量检索缓存，不再承载主数据语义。
- 支持无向量模式下的可用检索路径。
- 大规模笔记场景索引效率显著提升（数万条可在十几秒级完成索引）。
- 检索链路提速，整体稳定性提升。
- 存储体积明显下降。

### Core Changes
- `feat(core)`: 落地中央索引与记忆/笔记向量库同步链路。
- `refactor(memory)`: 统一记忆接口，根除关联字段与旧耦合。
- `feat(memory)`: 中央记忆迁移链路修复，补齐本地生成 ID 与中央目录管理。
- `refactor(config)`: 统一 `note_topk` 配置口径。
- `fix(notes-sync)`: 修正 notes 向量同步状态回写，并补充重建前日志。
- `perf(retrieval)`: 笔记向量召回阈值统一为 `0.5`。
- `chore(debug)`: 升级 debug tool，增强导入导出与可观测能力。

### Notes
- 本版本为重构里程碑版本，建议升级后执行一次初始化扫描与睡眠维护流程，确认索引状态一致。
