"""
ID转换服务 - 精简版ID转换接口

专注提供文件ID转换和资源管理。
"""

from typing import Optional

from ..components.file_index_manager import FileIndexManager

# 导入日志记录器
try:
    from astrbot.api import logger
except ImportError:
    import logging

    logger = logging.getLogger(__name__)


class IDServiceError(Exception):
    """ID服务异常基类"""

    pass


class IDConversionError(IDServiceError):
    """ID转换失败异常"""

    pass


class IDService:
    """
    精简版ID转换服务

    专注核心功能，提供单个文件ID转换和资源管理。
    """

    def __init__(self, plugin_context=None):
        """
        初始化ID服务

        Args:
            plugin_context: PluginContext插件上下文（可选，如果不提供则使用默认值）
        """
        self.logger = logger
        self.plugin_context = plugin_context

        # 从PluginContext获取资源，强制要求提供
        if plugin_context:
            self.data_directory = str(plugin_context.get_index_dir())
            self.provider_id = plugin_context.get_current_provider()
            path_manager = plugin_context.get_path_manager()
            self.file_index_directory = str(path_manager.get_memory_center_index_dir())
            self.file_index_provider = "global"
        else:
            # 不再使用默认值，强制要求PluginContext
            raise ValueError("PluginContext必须提供，无法使用默认配置")

        # 初始化底层管理器
        # 文件扫描状态属于中央真相源，不按 provider 分仓
        self.file_manager = FileIndexManager(
            self.file_index_directory, self.file_index_provider
        )

        self.logger.info(
            f"ID服务初始化完成 (提供商: {self.provider_id}, "
            f"文件索引目录: {self.file_index_directory}, 文件索引作用域: {self.file_index_provider})"
        )

    def file_to_id(self, file_path: str, timestamp: int = 0) -> int:
        """
        单个文件路径转ID

        Args:
            file_path: 文件路径
            timestamp: 文件时间戳（可选）

        Returns:
            文件ID

        Raises:
            IDConversionError: 当转换失败时抛出异常
        """
        try:
            return self.file_manager.get_or_create_file_id(file_path, timestamp)
        except Exception as e:
            self.logger.error(f"文件转ID失败: {file_path}, 错误: {e}")
            raise IDConversionError(f"文件转ID失败: {file_path}") from e

    def id_to_file(self, file_id: int) -> Optional[str]:
        """
        单个ID转文件路径

        Args:
            file_id: 文件ID

        Returns:
            文件路径，如果不存在返回None
        """
        try:
            return self.file_manager.get_file_path(file_id)
        except Exception as e:
            self.logger.error(f"ID转文件失败: {file_id}, 错误: {e}")
            return None

    def close(self):
        """关闭服务，释放资源"""
        try:
            self.file_manager.close()
        except Exception as e:
            self.logger.error(f"关闭ID服务失败: {e}")

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def __str__(self) -> str:
        """字符串表示"""
        return f"IDService(provider={self.provider_id}, dir={self.data_directory})"

    @classmethod
    def from_plugin_context(cls, plugin_context):
        """
        从PluginContext创建IDService实例

        Args:
            plugin_context: PluginContext插件上下文

        Returns:
            IDService实例
        """
        return cls(plugin_context)
