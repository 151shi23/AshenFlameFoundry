"""
记忆插件配置管理

处理插件的配置选项和默认值。
"""

from typing import Any, Dict, Union
from dataclasses import dataclass


class ConfigValidator:
    """通用配置验证器"""

    @staticmethod
    def validate_positive_int(value: Any, field_name: str, max_value: int = None) -> int:
        """验证正整数"""
        if not isinstance(value, int) or isinstance(value, bool) or value < 1:
            raise ValueError(f"{field_name} must be a positive integer, got: {value}")
        if max_value is not None and value > max_value:
            raise ValueError(f"{field_name} too large (max {max_value}), got: {value}")
        return value

    @staticmethod
    def validate_non_negative_int(
        value: Any, field_name: str, max_value: int = None
    ) -> int:
        """验证非负整数"""
        if not isinstance(value, int) or isinstance(value, bool) or value < 0:
            raise ValueError(
                f"{field_name} must be a non-negative integer, got: {value}"
            )
        if max_value is not None and value > max_value:
            raise ValueError(f"{field_name} too large (max {max_value}), got: {value}")
        return value

    @staticmethod
    def validate_positive_number(
        value: Any, field_name: str, max_value: Union[int, float] = None
    ) -> float:
        """验证正数（整数或浮点数）"""
        if not isinstance(value, (int, float)) or isinstance(value, bool) or value <= 0:
            raise ValueError(f"{field_name} must be a positive number, got: {value}")
        if max_value is not None and value > max_value:
            raise ValueError(f"{field_name} too large (max {max_value}), got: {value}")
        return float(value)

    @staticmethod
    def validate_bool(value: Any, field_name: str) -> bool:
        """验证布尔值"""
        if not isinstance(value, bool):
            raise ValueError(
                f"{field_name} must be a boolean, got: {type(value).__name__}"
            )
        return value

    @staticmethod
    def validate_range_order(min_val: Any, mid_val: Any, max_val: Any, field_prefix: str) -> None:
        """验证范围顺序 min <= mid <= max"""
        if not (min_val <= mid_val <= max_val):
            raise ValueError(
                f"{field_prefix} range order invalid: min({min_val}) <= mid({mid_val}) <= max({max_val}) not satisfied"
            )


@dataclass
class MemoryCapacityConfig:
    """记忆容量配置类"""

    knowledge: int = 14  # 普通知识记忆容量
    knowledge_user_info: int = 14  # 用户信息专用知识记忆容量
    emotional: int = 1
    skill: int = 7
    task: int = 1
    event: int = 3


class MemoryConstants:
    """记忆系统常量定义"""

    MIN_MESSAGE_LENGTH = 5
    SHORT_TERM_MEMORY_CAPACITY = 1.0
    DEFAULT_DATA_DIR = None  # 数据目录必须由外部传入，不设默认值
    NOTE_TOP_K = 3  # 默认注入笔记数量（候选固定为 7 倍）

    # 时间常量（秒）
    TIME_SECOND = 1
    TIME_MINUTE = 60
    TIME_HOUR = 3600
    TIME_DAY = 86400

    # 记忆类型映射
    MEMORY_TYPE_NAMES = {
        "knowledge": "知识",
        "event": "事件",
        "skill": "技能",
        "emotional": "情感",
        "task": "任务",
        "meta": "元记忆",
    }

    MEMORY_TYPE_MAPPING = {
        "知识记忆": "knowledge",
        "事件记忆": "event",
        "技能记忆": "skill",
        "任务记忆": "task",
        "情感记忆": "emotional",
        "元记忆": "meta",
    }


class MemoryConfig:
    """记忆插件配置类

    负责管理插件的用户可配置参数，与llm_memory的系统配置形成分层结构：
    - 本类：用户级别的插件配置（min_message_length, short_term_memory_capacity等）
    - system_config：系统级别的技术配置（向量存储、嵌入模型等）

    配置验证确保用户输入的参数在合理范围内，防止异常配置导致系统不稳定。
    """

    def __init__(
        self,
        config: Dict[str, Any] | None = None,
        data_dir: str = MemoryConstants.DEFAULT_DATA_DIR,
    ):
        """
        初始化配置

        Args:
            config: 配置字典
            data_dir: 数据目录路径
        """
        self.config = config or {}
        self.data_dir = data_dir

        # 预计算常用配置值（使用通用验证器）
        config_get = self.config.get

        # 记忆行为参数配置 - 支持新旧格式兼容
        # 新格式：memory_behavior.min_message_length
        # 旧格式：min_message_length
        memory_behavior = config_get("memory_behavior", {})

        self._min_message_length = ConfigValidator.validate_positive_int(
            memory_behavior.get("min_message_length") or config_get("min_message_length", MemoryConstants.MIN_MESSAGE_LENGTH),
            "min_message_length",
            max_value=500,
        )
        self._short_term_memory_capacity = ConfigValidator.validate_positive_number(
            memory_behavior.get("short_term_memory_capacity") or config_get("short_term_memory_capacity", MemoryConstants.SHORT_TERM_MEMORY_CAPACITY),
            "short_term_memory_capacity",
            max_value=10.0,
        )
        self._default_passive_strength = ConfigValidator.validate_positive_int(
            memory_behavior.get("default_passive_strength") or config_get("default_passive_strength", 10),
            "default_passive_strength",
            max_value=100,
        )

        self._data_directory = config_get("data_directory", self.data_dir)
        self._provider_id = config_get("provider_id", "")
        retrieval = config_get("retrieval", {}) or {}
        if not isinstance(retrieval, dict):
            retrieval = {}
        self._rerank_provider_id = str(
            retrieval.get("rerank_provider_id")
            or config_get("rerank_provider_id", "")
            or ""
        )

        # 向量请求参数（retrieval 下，兼容顶层旧字段）
        if "embedding_batch_size" in retrieval:
            _raw_batch = retrieval.get("embedding_batch_size")
        else:
            _raw_batch = config_get("embedding_batch_size", 50)
        self._embedding_batch_size = ConfigValidator.validate_positive_int(
            _raw_batch,
            "retrieval.embedding_batch_size",
        )
        if "embedding_timeout" in retrieval:
            _raw_timeout = retrieval.get("embedding_timeout")
        else:
            _raw_timeout = config_get("embedding_timeout", 5)
        self._embedding_timeout = ConfigValidator.validate_positive_int(
            _raw_timeout,
            "retrieval.embedding_timeout",
            max_value=120,
        )
        if "rerank_max_docs" in retrieval:
            _raw_rerank_docs = retrieval.get("rerank_max_docs")
        else:
            _raw_rerank_docs = config_get("rerank_max_docs", 64)
        self._rerank_max_docs = ConfigValidator.validate_positive_int(
            _raw_rerank_docs,
            "retrieval.rerank_max_docs",
            max_value=200,
        )
        if "rerank_max_tokens_per_doc" in retrieval:
            _raw_rerank_tokens = retrieval.get("rerank_max_tokens_per_doc")
        else:
            _raw_rerank_tokens = config_get("rerank_max_tokens_per_doc", 1024)
        self._rerank_max_tokens_per_doc = ConfigValidator.validate_positive_int(
            _raw_rerank_tokens,
            "retrieval.rerank_max_tokens_per_doc",
            max_value=8192,
        )

        # 笔记 Top-K 配置（候选固定为注入的 7 倍）
        note_assistant = config_get("note_assistant", {})
        if not isinstance(note_assistant, dict):
            note_assistant = {}
        note_topk_raw = note_assistant.get("top_k", None)
        if note_topk_raw is None:
            # 兼容旧格式
            note_topk = config_get("note_topk", {})
            note_topk_raw = note_topk.get("top_k", MemoryConstants.NOTE_TOP_K) if isinstance(note_topk, dict) else MemoryConstants.NOTE_TOP_K
        self._note_top_k = ConfigValidator.validate_non_negative_int(
            note_topk_raw,
            "note_assistant.top_k",
            max_value=1000,
        )
        self._note_candidate_top_k = self._note_top_k * 7
        self._note_inject_top_k = self._note_top_k
        legacy_local_embedding = bool(config_get("enable_local_embedding", False))
        new_local_embedding = bool(retrieval.get("enable_local_embedding", False))
        new_embedding_id = str(retrieval.get("embedding_provider_id", "") or "").strip()
        new_rerank_id = str(retrieval.get("rerank_provider_id", "") or "").strip()
        if (
            "enable_local_embedding" in retrieval
            and not new_local_embedding
            and not new_embedding_id
            and not new_rerank_id
            and legacy_local_embedding
        ):
            self._enable_local_embedding = legacy_local_embedding
        else:
            self._enable_local_embedding = (
                new_local_embedding if "enable_local_embedding" in retrieval else legacy_local_embedding
            )
        self._conversation_scope_map = config_get("conversation_scope_map", {}) or {}

        # 灵魂系统配置 - 支持新旧格式兼容
        # 新格式：enable_soul_system.enabled, enable_soul_system.recall_depth_mid
        # 旧格式：enable_soul_system (bool), soul_recall_depth_mid
        soul_system_config = config_get("enable_soul_system", {})

        # 兼容旧格式：如果enable_soul_system是bool，转换为新格式
        if isinstance(soul_system_config, bool):
            self._enable_soul_system = soul_system_config
            soul_system_config = {}
        else:
            self._enable_soul_system = ConfigValidator.validate_bool(
                soul_system_config.get("enabled", True),
                "enable_soul_system.enabled"
            )

        # RecallDepth 参数 - 优先使用新格式，其次旧格式，最后默认值
        self._soul_recall_depth_min = ConfigValidator.validate_positive_int(
            config_get("soul_recall_depth_min", 3),
            "soul_recall_depth_min"
        )
        self._soul_recall_depth_mid = ConfigValidator.validate_positive_int(
            soul_system_config.get("recall_depth_mid") or config_get("soul_recall_depth_mid", 7),
            "soul_recall_depth_mid"
        )
        self._soul_recall_depth_max = ConfigValidator.validate_positive_int(
            config_get("soul_recall_depth_max", 20),
            "soul_recall_depth_max"
        )
        ConfigValidator.validate_range_order(
            self._soul_recall_depth_min,
            self._soul_recall_depth_mid,
            self._soul_recall_depth_max,
            "soul_recall_depth"
        )

        # ImpressionDepth 参数
        self._soul_impression_depth_min = ConfigValidator.validate_positive_int(
            config_get("soul_impression_depth_min", 1),
            "soul_impression_depth_min"
        )
        self._soul_impression_depth_mid = ConfigValidator.validate_positive_int(
            soul_system_config.get("impression_depth_mid") or config_get("soul_impression_depth_mid", 3),
            "soul_impression_depth_mid"
        )
        self._soul_impression_depth_max = ConfigValidator.validate_positive_int(
            config_get("soul_impression_depth_max", 10),
            "soul_impression_depth_max"
        )
        ConfigValidator.validate_range_order(
            self._soul_impression_depth_min,
            self._soul_impression_depth_mid,
            self._soul_impression_depth_max,
            "soul_impression_depth"
        )

        # ExpressionDesire 参数 - 使用归一化值(0-1)
        self._soul_expression_desire_min = ConfigValidator.validate_positive_number(
            config_get("soul_expression_desire_min", 0.0),
            "soul_expression_desire_min",
            max_value=1.0
        )
        self._soul_expression_desire_mid = ConfigValidator.validate_positive_number(
            soul_system_config.get("expression_desire_mid") or config_get("soul_expression_desire_mid", 0.5),
            "soul_expression_desire_mid",
            max_value=1.0
        )
        self._soul_expression_desire_max = ConfigValidator.validate_positive_number(
            config_get("soul_expression_desire_max", 1.0),
            "soul_expression_desire_max",
            max_value=1.0
        )
        ConfigValidator.validate_range_order(
            self._soul_expression_desire_min,
            self._soul_expression_desire_mid,
            self._soul_expression_desire_max,
            "soul_expression_desire"
        )

        # Creativity 参数 - 使用归一化值(0-1)
        self._soul_creativity_min = ConfigValidator.validate_positive_number(
            config_get("soul_creativity_min", 0.0),
            "soul_creativity_min",
            max_value=1.0
        )
        self._soul_creativity_mid = ConfigValidator.validate_positive_number(
            soul_system_config.get("creativity_mid") or config_get("soul_creativity_mid", 0.7),
            "soul_creativity_mid",
            max_value=1.0
        )
        self._soul_creativity_max = ConfigValidator.validate_positive_number(
            config_get("soul_creativity_max", 1.0),
            "soul_creativity_max",
            max_value=1.0
        )
        ConfigValidator.validate_range_order(
            self._soul_creativity_min,
            self._soul_creativity_mid,
            self._soul_creativity_max,
            "soul_creativity"
        )

    @property
    def min_message_length(self) -> int:
        """获取最小消息长度"""
        return self._min_message_length

    @property
    def short_term_memory_capacity(self) -> float:
        """获取短期记忆容量倍数"""
        return self._short_term_memory_capacity

    @property
    def default_passive_strength(self) -> int:
        """获取被动记忆默认强度"""
        return self._default_passive_strength

    @property
    def data_directory(self) -> str:
        """获取数据目录路径"""
        return self._data_directory

    @property
    def provider_id(self) -> str:
        """获取记忆整理LLM提供商ID"""
        return self._provider_id

    @property
    def rerank_provider_id(self) -> str:
        """获取记忆二阶段重排提供商ID"""
        return self._rerank_provider_id

    @property
    def embedding_batch_size(self) -> int:
        """获取向量请求批次大小"""
        return self._embedding_batch_size

    @property
    def embedding_timeout(self) -> int:
        """获取向量请求超时时间（秒）"""
        return self._embedding_timeout

    @property
    def rerank_max_docs(self) -> int:
        """获取重排候选数量上限"""
        return self._rerank_max_docs

    @property
    def rerank_max_tokens_per_doc(self) -> int:
        """获取重排单段 token 上限"""
        return self._rerank_max_tokens_per_doc

    @property
    def note_candidate_top_k(self) -> int:
        """获取候选笔记数量上限"""
        return self._note_candidate_top_k

    @property
    def note_inject_top_k(self) -> int:
        """获取注入笔记数量上限"""
        return self._note_inject_top_k
    @property
    def note_top_k(self) -> int:
        """获取统一注入Top-K配置值"""
        return self._note_top_k
    @property
    def enable_local_embedding(self) -> bool:
        """是否启用本地嵌入模型"""
        return self._enable_local_embedding

    @property
    def conversation_scope_map(self) -> Dict[str, Any]:
        """会话ID到记忆分类域的映射表（原始值，校验由PluginContext负责）。"""
        return self._conversation_scope_map

    @property
    def enable_soul_system(self) -> bool:
        """是否启用灵魂系统"""
        return self._enable_soul_system

    # 灵魂参数属性
    @property
    def soul_recall_depth_min(self) -> int: return self._soul_recall_depth_min
    @property
    def soul_recall_depth_mid(self) -> int: return self._soul_recall_depth_mid
    @property
    def soul_recall_depth_max(self) -> int: return self._soul_recall_depth_max

    @property
    def soul_impression_depth_min(self) -> int: return self._soul_impression_depth_min
    @property
    def soul_impression_depth_mid(self) -> int: return self._soul_impression_depth_mid
    @property
    def soul_impression_depth_max(self) -> int: return self._soul_impression_depth_max

    @property
    def soul_expression_desire_min(self) -> float: return self._soul_expression_desire_min
    @property
    def soul_expression_desire_mid(self) -> float: return self._soul_expression_desire_mid
    @property
    def soul_expression_desire_max(self) -> float: return self._soul_expression_desire_max

    @property
    def soul_creativity_min(self) -> float: return self._soul_creativity_min
    @property
    def soul_creativity_mid(self) -> float: return self._soul_creativity_mid
    @property
    def soul_creativity_max(self) -> float: return self._soul_creativity_max

    def get_config_value(self, key: str, default: Any = None) -> Any:
        """
        获取配置值

        Args:
            key: 配置键
            default: 默认值

        Returns:
            配置值
        """
        return self.config.get(key, default)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "min_message_length": self.min_message_length,
            "short_term_memory_capacity": self.short_term_memory_capacity,
            "default_passive_strength": self.default_passive_strength,
            "enable_local_embedding": self.enable_local_embedding,
            "conversation_scope_map": self.conversation_scope_map,
            "enable_soul_system": self.enable_soul_system,
            "data_directory": self.data_directory,
            "provider_id": self.provider_id,
            "rerank_provider_id": self.rerank_provider_id,
            "embedding_batch_size": self.embedding_batch_size,
            "embedding_timeout": self.embedding_timeout,
            "rerank_max_docs": self.rerank_max_docs,
            "rerank_max_tokens_per_doc": self.rerank_max_tokens_per_doc,
            "note_top_k": self.note_top_k,
            "note_candidate_top_k": self.note_candidate_top_k,
            "note_inject_top_k": self.note_inject_top_k,
        }

    def get_capacity_config(self) -> MemoryCapacityConfig:
        """获取记忆容量配置"""
        return MemoryCapacityConfig()
