"""睡眠调度时刻计算。

本机改动（上游写死 04:00）：这台机器凌晨是关着的，04:00 的睡眠从来没触发过，
整理/固化等于永久停摆，所以挪到白天有人聊、机器也开着的 21:05。
进程在该时刻未运行时当天不补偿，启动时只重算下一次触发时刻。
"""

from __future__ import annotations

import datetime
import time

SLEEP_HOUR = 21
SLEEP_MINUTE = 5


def seconds_until_next_sleep(now: float | None = None) -> float:
    """距下一个 04:00 的秒数。"""
    current = datetime.datetime.fromtimestamp(
        time.time() if now is None else float(now)
    )
    target = current.replace(
        hour=SLEEP_HOUR, minute=SLEEP_MINUTE, second=0, microsecond=0
    )
    if target <= current:
        target += datetime.timedelta(days=1)
    return max(1.0, (target - current).total_seconds())


def today_key(now: float | None = None) -> str:
    """当前日期键，用于「同一天只跑一次」判定。"""
    return time.strftime(
        "%Y-%m-%d", time.localtime(time.time() if now is None else float(now))
    )


def should_run_sleep(last_sleep_day: str, now: float | None = None) -> bool:
    """今天是否还没跑过睡眠。"""
    return str(last_sleep_day or "") != today_key(now)
