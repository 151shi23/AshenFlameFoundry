"""
记忆格式化器

负责将记忆格式化为统一的文本格式，便于阅读和理解。
"""

from types import SimpleNamespace
from typing import List, Dict, Any, Optional
import time

from ..session_memory import MemoryItem
from ..config import MemoryConstants


class MemoryFormatter:
    """记忆格式化器"""

    # 记忆类型到中文的映射
    MEMORY_TYPE_NAMES = MemoryConstants.MEMORY_TYPE_NAMES

    @staticmethod
    def format_single_memory(memory: MemoryItem, short_id: str = "") -> str:
        """
        格式化单条记忆

        Args:
            memory: 记忆对象
            short_id: 短 ID 字符串（如果提供则前置显示）

        Returns:
            格式化后的记忆文本
        """
        # 格式化论点
        judgment = str(getattr(memory, "judgment", "") or "").strip()

        # 格式化理由
        reasoning = ""
        memory_reasoning = str(getattr(memory, "reasoning", "") or "")
        if memory_reasoning and memory_reasoning.strip():
            reasoning = f"\n——因为{memory_reasoning.strip()}"

        # 格式化时间（相对时间）
        time_suffix = ""
        created_at = getattr(memory, "created_at", 0.0)
        if created_at and created_at > 0:
            elapsed = time.time() - created_at
            if elapsed < 60:
                time_suffix = "（刚刚）"
            elif elapsed < 3600:
                time_suffix = f"（{int(elapsed // 60)}分钟前）"
            elif elapsed < 86400:
                time_suffix = f"（{int(elapsed // 3600)}小时前）"
            elif elapsed < 2592000:
                time_suffix = f"（{int(elapsed // 86400)}天前）"
            else:
                time_suffix = f"（{int(elapsed // 2592000)}个月前）"

        id_prefix = f"[{short_id}] " if short_id else ""
        return f"{id_prefix}{judgment}{reasoning}{time_suffix}"

    @staticmethod
    def format_memories_by_type(memories: List[MemoryItem]) -> Dict[str, List[str]]:
        """
        按类型分组格式化记忆

        Args:
            memories: 记忆列表

        Returns:
            按类型分组的格式化记忆字典
        """
        # 按类型分组（使用setdefault简化）
        grouped_memories = {}
        for memory in memories:
            # 处理 MemoryItem 对象的 memory_type 属性
            type_value = (
                memory.memory_type.value
                if hasattr(memory.memory_type, "value")
                else memory.memory_type
            )
            type_value = MemoryConstants.MEMORY_TYPE_MAPPING.get(
                type_value, str(type_value or "").lower()
            )
            type_name = MemoryFormatter.MEMORY_TYPE_NAMES.get(type_value, type_value)
            grouped_memories.setdefault(type_name, []).append(
                MemoryFormatter.format_single_memory(memory)
            )
        return grouped_memories

    @staticmethod
    def format_memories_for_prompt(
        memories: List[MemoryItem],
        useful_memory_ids: Optional[List[str]] = None,
        action_memories: Optional[List[Dict[str, Any]]] = None,
    ) -> str:
        """
        格式化记忆用于提示词

        Args:
            memories: 记忆列表
            useful_memory_ids: 有用记忆ID列表
            action_memories: 动作中产出的新记忆列表

        Returns:
            格式化后的记忆文本
        """
        if not memories and not action_memories:
            return ""

        # 创建ID到记忆的映射
        memory_map = {memory.id: memory for memory in memories}
        memories_to_format = []

        # 添加有用的历史记忆（使用列表推导式）
        if useful_memory_ids:
            memories_to_format.extend(
                memory_map[mid] for mid in useful_memory_ids if mid in memory_map
            )

        # 添加新记忆（使用列表推导式）
        if action_memories:
            memories_to_format.extend(
                SimpleNamespace(
                    id=nm.get("id", "new"),
                    memory_type=nm.get("type", "knowledge"),
                    judgment=nm.get("judgment", ""),
                    reasoning=nm.get("reasoning", ""),
                    tags=nm.get("tags", []),
                    strength=nm.get("strength", 0.5),
                    created_at=time.time(),
                )
                for nm in action_memories
            )

        if not memories_to_format:
            return ""

        # 按类型分组并格式化
        grouped_memories = MemoryFormatter.format_memories_by_type(memories_to_format)

        # 构建最终文本（使用extend简化）
        formatted_lines = ["[相关记忆]"]
        for memory_type, formatted_memories in grouped_memories.items():
            formatted_lines.append(f"\n[{memory_type}]")
            formatted_lines.extend(
                f"\n{memory_text}" for memory_text in formatted_memories
            )

        return "".join(formatted_lines)

    @staticmethod
    def _deduplicate_memories(memories: List[MemoryItem]) -> List[MemoryItem]:
        """
        去重记忆列表，基于judgment文本内容

        Args:
            memories: 记忆列表

        Returns:
            去重后的记忆列表
        """
        seen_judgments = set()
        deduplicated = []

        for memory in memories:
            # 标准化judgment文本用于比较
            normalized_judgment = str(getattr(memory, "judgment", "") or "").strip().lower()
            if normalized_judgment not in seen_judgments:
                seen_judgments.add(normalized_judgment)
                deduplicated.append(memory)

        return deduplicated

    @staticmethod
    def format_session_memories(memories: List[MemoryItem], short_id_registry=None) -> str:
        """
        格式化会话工作记忆列表，无过滤，但会去重。每条记忆带全局短 ID。

        Args:
            memories: 记忆列表
            short_id_registry: 全局短 ID 注册表（可选，提供时输出短 ID）

        Returns:
            格式化后的记忆文本
        """
        if not memories:
            return ""

        # 去重处理
        deduplicated_memories = MemoryFormatter._deduplicate_memories(memories)

        # 按类型分组（保留原始对象以便获取 ID）
        grouped = {}
        for memory in deduplicated_memories:
            type_value = (
                memory.memory_type.value
                if hasattr(memory.memory_type, "value")
                else memory.memory_type
            )
            type_value = MemoryConstants.MEMORY_TYPE_MAPPING.get(
                type_value, str(type_value or "").lower()
            )
            type_name = MemoryFormatter.MEMORY_TYPE_NAMES.get(type_value, type_value)
            grouped.setdefault(type_name, []).append(memory)

        # 构建最终文本
        formatted_lines = ["[相关记忆]"]
        for memory_type, memory_list in grouped.items():
            formatted_lines.append(f"\n[{memory_type}]")
            for memory in memory_list:
                short_id = ""
                if short_id_registry is not None:
                    mem_id = str(getattr(memory, "id", "") or "").strip()
                    if mem_id:
                        short_id = short_id_registry.get_short_id(mem_id)
                formatted_lines.append(
                    f"\n{MemoryFormatter.format_single_memory(memory, short_id=short_id)}"
                )

        return "".join(formatted_lines)

    

    @staticmethod
    def format_memories_for_display(memories: List[MemoryItem]) -> str:
        """
        格式化记忆用于显示

        Args:
            memories: 记忆列表

        Returns:
            格式化后的记忆文本
        """
        if not memories:
            return "暂无记忆"

        # 按类型分组（保留原始对象）
        grouped = {}
        for memory in memories:
            # 处理 MemoryItem 对象的 memory_type 属性
            type_value = (
                memory.memory_type.value
                if hasattr(memory.memory_type, "value")
                else memory.memory_type
            )
            type_value = MemoryConstants.MEMORY_TYPE_MAPPING.get(
                type_value, str(type_value or "").lower()
            )
            type_name = MemoryFormatter.MEMORY_TYPE_NAMES.get(type_value, type_value)
            grouped.setdefault(type_name, []).append(memory)

        # 使用自增序号作为短 ID
        display_lines = []
        counter = 0
        for memory_type, memory_list in grouped.items():
            display_lines.append(f"\n=== {memory_type} ===")
            for i, memory in enumerate(memory_list, 1):
                short_id = f"m{counter}"
                counter += 1
                judgment = str(getattr(memory, "judgment", "") or "").strip()
                reasoning = (
                    f"\n   ——因为{str(getattr(memory, 'reasoning', '') or '').strip()}"
                    if str(getattr(memory, "reasoning", "") or "").strip()
                    else ""
                )
                display_lines.append(f"\n{i}. [id:{short_id}]{judgment}{reasoning}")

        return "".join(display_lines)
