from __future__ import annotations

import asyncio
import json
import sqlite3
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

try:
    from astrbot.api import logger
except ImportError:
    import logging

    logger = logging.getLogger(__name__)

from ..config.system_config import system_config
from ..models.data_models import BaseMemory, MemoryType, ValidationError
from ..utils.user_profile import (
    PROFILE_ATTRIBUTE_TAGS,
    is_user_profile_tags,
)
from ..service.memory_decay_policy import MemoryDecayConfig, MemoryDecayPolicy
from .bm25_retriever import TantivyBM25Retriever
from .hybrid_retrieval_engine import HybridRetrievalEngine


class MemorySqlManager:
    """SimpleMemory 的 SQL 存储管理器。"""

    def __init__(
        self,
        db_path: Path,
        decay_config: Optional[MemoryDecayConfig] = None,
        rerank_provider: Optional[Any] = None,
        rerank_timeout: int | None = None,
        rerank_max_docs: int | None = None,
        rerank_max_tokens_per_doc: int | None = None,
    ):
        self.logger = logger
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._fts_lock = threading.Lock()
        self._tag_names: set[str] = set()
        self._fts_rebuild_required = False
        self.decay_policy = MemoryDecayPolicy(decay_config)
        self._rerank_provider = rerank_provider
        try:
            _to = int(rerank_timeout) if rerank_timeout is not None else 5
        except Exception:
            _to = 5
        self._rerank_timeout = max(5, min(120, _to))
        try:
            _md = int(rerank_max_docs) if rerank_max_docs is not None else 64
        except Exception:
            _md = 64
        self._rerank_max_docs = max(1, min(200, _md))
        try:
            _mt = int(rerank_max_tokens_per_doc) if rerank_max_tokens_per_doc is not None else 1024
        except Exception:
            _mt = 1024
        self._rerank_max_tokens_per_doc = max(128, min(8192, _mt))
        self._fts_retriever = TantivyBM25Retriever(
            db_path=str(self.db_path),
            memory_threshold=0.5,
            memory_default_vector_score=0.5,
        )
        self._hybrid_engine = HybridRetrievalEngine(
            retriever=self._fts_retriever,
            rerank_provider=self._rerank_provider,
            rerank_timeout=self._rerank_timeout,
            rerank_max_docs=self._rerank_max_docs,
            rerank_max_tokens_per_doc=self._rerank_max_tokens_per_doc,
        )
        self._fts_ready = False

        self._init_db()
        self._load_tag_cache()
        self._init_short_id_registry()
        # 启动阶段检查检索索引：格式版本一致时直接复用，避免每次启动全量重建。
        start_ts = time.time()
        self._ensure_fts_ready_sync()
        elapsed_ms = int((time.time() - start_ts) * 1000)
        self.logger.info(f"[检索索引] 启动就绪检查完成 耗时={elapsed_ms}ms")

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path), check_same_thread=False, timeout=30.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA busy_timeout=30000")
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            cur = conn.cursor()
            cur.executescript(
                """
                CREATE TABLE IF NOT EXISTS memory_records (
                    id TEXT PRIMARY KEY,
                    memory_type TEXT NOT NULL,
                    judgment TEXT NOT NULL,
                    reasoning TEXT NOT NULL,
                    strength INTEGER NOT NULL,
                    is_active INTEGER NOT NULL,
                    useful_count INTEGER NOT NULL DEFAULT 0,
                    useful_score REAL NOT NULL DEFAULT 0,
                    last_recalled_at REAL NOT NULL DEFAULT 0,
                    last_decay_at REAL NOT NULL DEFAULT 0,
                    memory_scope TEXT NOT NULL,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS global_tags (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL UNIQUE
                );

                CREATE TABLE IF NOT EXISTS memory_tag_rel (
                    memory_id TEXT NOT NULL,
                    tag_id INTEGER NOT NULL,
                    UNIQUE(memory_id, tag_id)
                );

                CREATE TABLE IF NOT EXISTS note_index_records (
                    source_id TEXT PRIMARY KEY,
                    note_short_id INTEGER UNIQUE,
                    file_id TEXT NOT NULL,
                    source_file_path TEXT NOT NULL,
                    heading_h1 TEXT,
                    heading_h2 TEXT,
                    heading_h3 TEXT,
                    heading_h4 TEXT,
                    heading_h5 TEXT,
                    heading_h6 TEXT,
                    total_lines INTEGER NOT NULL DEFAULT 0,
                    updated_at REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS user_ledger (
                    platform TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    user_names TEXT NOT NULL DEFAULT '[]',
                    first_seen_at REAL NOT NULL,
                    last_seen_at REAL NOT NULL,
                    PRIMARY KEY (platform, user_id)
                );

                CREATE TABLE IF NOT EXISTS group_ledger (
                    group_id TEXT PRIMARY KEY,
                    group_name TEXT NOT NULL DEFAULT '',
                    first_seen_at REAL NOT NULL,
                    last_seen_at REAL NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_memory_scope_created_at
                    ON memory_records(memory_scope, created_at);
                CREATE INDEX IF NOT EXISTS idx_memory_active_strength
                    ON memory_records(is_active, strength);
                CREATE INDEX IF NOT EXISTS idx_memory_judgment
                    ON memory_records(judgment);
                CREATE INDEX IF NOT EXISTS idx_memory_tag_rel_tag_memory
                    ON memory_tag_rel(tag_id, memory_id);
                CREATE INDEX IF NOT EXISTS idx_note_index_file_id
                    ON note_index_records(file_id);
                CREATE INDEX IF NOT EXISTS idx_note_index_path
                    ON note_index_records(source_file_path);

                CREATE TABLE IF NOT EXISTS note_short_id_seq (
                    id INTEGER PRIMARY KEY CHECK (id = 1),
                    next_id INTEGER NOT NULL
                );
                """
            )
            # 兼容迁移：若旧表 memory_tags 存在，则迁移到 global_tags
            has_legacy = cur.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='memory_tags'"
            ).fetchone()
            if has_legacy:
                cur.execute(
                    "INSERT OR IGNORE INTO global_tags(name) SELECT name FROM memory_tags"
                )
            # 兼容迁移：note_index_records 补充 total_lines 列
            note_columns = cur.execute("PRAGMA table_info(note_index_records)").fetchall()
            column_names = {str(row[1]) for row in note_columns}
            if "note_short_id" not in column_names:
                cur.execute("ALTER TABLE note_index_records ADD COLUMN note_short_id INTEGER")
            if "total_lines" not in column_names:
                cur.execute(
                    "ALTER TABLE note_index_records ADD COLUMN total_lines INTEGER NOT NULL DEFAULT 0"
                )
            # 初始化短ID序列
            cur.execute("INSERT OR IGNORE INTO note_short_id_seq(id, next_id) VALUES (1, 0)")
            # 兼容迁移：给历史 note_index_records 补 note_short_id（从0开始）
            rows_without_short_id = cur.execute(
                """
                SELECT source_id
                FROM note_index_records
                WHERE note_short_id IS NULL
                ORDER BY source_id ASC
                """
            ).fetchall()
            if rows_without_short_id:
                seq_row = cur.execute(
                    "SELECT next_id FROM note_short_id_seq WHERE id = 1"
                ).fetchone()
                next_id = int(seq_row[0]) if seq_row else 0
                for row in rows_without_short_id:
                    cur.execute(
                        "UPDATE note_index_records SET note_short_id = ? WHERE source_id = ?",
                        (next_id, str(row[0])),
                    )
                    next_id += 1
                cur.execute(
                    "UPDATE note_short_id_seq SET next_id = ? WHERE id = 1",
                    (next_id,),
                )
            # 兼容迁移：memory_records 补充三档记忆字段
            memory_columns = cur.execute("PRAGMA table_info(memory_records)").fetchall()
            memory_column_names = {str(row[1]) for row in memory_columns}
            if "useful_count" not in memory_column_names:
                cur.execute(
                    "ALTER TABLE memory_records ADD COLUMN useful_count INTEGER NOT NULL DEFAULT 0"
                )
            if "useful_score" not in memory_column_names:
                cur.execute(
                    "ALTER TABLE memory_records ADD COLUMN useful_score REAL NOT NULL DEFAULT 0"
                )
            if "last_recalled_at" not in memory_column_names:
                cur.execute(
                    "ALTER TABLE memory_records ADD COLUMN last_recalled_at REAL NOT NULL DEFAULT 0"
                )
            if "last_decay_at" not in memory_column_names:
                cur.execute(
                    "ALTER TABLE memory_records ADD COLUMN last_decay_at REAL NOT NULL DEFAULT 0"
                )
            # 索引创建放在补列之后，避免旧库因缺列导致初始化失败
            cur.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_memory_tier_fields
                    ON memory_records(is_active, useful_score, last_recalled_at)
                """
            )
            cur.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_note_index_short_id
                    ON note_index_records(note_short_id)
                """
            )
            conn.commit()

    def _load_tag_cache(self) -> None:
        with self._connect() as conn:
            rows = conn.execute("SELECT name FROM global_tags").fetchall()
            with self._lock:
                self._tag_names = {str(row["name"]) for row in rows if row["name"]}
        self.logger.info(f"SimpleMemory 标签缓存加载完成: {len(self._tag_names)} 个")

    # ===== 全局短 ID 注册表（内存态） =====

    def _init_short_id_registry(self) -> None:
        """启动时加载全部记忆 ID，分配纯数字短 ID（从 10000 开始递增）。"""
        self._short_to_full: Dict[str, str] = {}
        self._full_to_short: Dict[str, str] = {}
        self._next_short_id: int = 10000

        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id FROM memory_records ORDER BY created_at ASC"
            ).fetchall()

        for row in rows:
            full_id = str(row["id"]).strip()
            if full_id and full_id not in self._full_to_short:
                short_id = str(self._next_short_id)
                self._short_to_full[short_id] = full_id
                self._full_to_short[full_id] = short_id
                self._next_short_id += 1

        self.logger.info(
            f"[短ID注册表] 初始化完成 记忆数={len(self._full_to_short)} "
            f"下一个短ID={self._next_short_id}"
        )

    def register_short_id(self, full_id: str) -> str:
        """为新记忆分配短 ID 并注册。如果已存在则直接返回。"""
        full_id = str(full_id or "").strip()
        if not full_id:
            return ""
        with self._lock:
            if full_id in self._full_to_short:
                return self._full_to_short[full_id]
            short_id = str(self._next_short_id)
            self._short_to_full[short_id] = full_id
            self._full_to_short[full_id] = short_id
            self._next_short_id += 1
        return short_id

    def get_short_id(self, full_id: str) -> str:
        """根据完整 ID 获取短 ID，未注册则返回空字符串。"""
        return self._full_to_short.get(str(full_id or "").strip(), "")

    def get_full_id(self, short_id: str) -> str:
        """根据短 ID 获取完整 ID，未注册则返回空字符串。"""
        return self._short_to_full.get(str(short_id or "").strip(), "")

    def build_id_mapping(self, full_ids: List[str]) -> Dict[str, str]:
        """为一组完整 ID 构建 {短ID: 完整ID} 映射（用于反思等场景）。"""
        mapping: Dict[str, str] = {}
        for full_id in full_ids:
            short_id = self.get_short_id(full_id)
            if short_id:
                mapping[short_id] = full_id
        return mapping

    def get_short_ids_by_paths_sync(self, paths: List[str]) -> Dict[str, int]:
        """根据 source_file_path 列表查询对应的 note_short_id。

        Returns:
            {source_file_path: note_short_id} 映射
        """
        if not paths:
            return {}
        with self._connect() as conn:
            placeholders = ",".join(["?" for _ in paths])
            rows = conn.execute(
                f"SELECT source_file_path, note_short_id FROM note_index_records "
                f"WHERE source_file_path IN ({placeholders}) AND note_short_id IS NOT NULL "
                f"ORDER BY note_short_id ASC",
                tuple(paths),
            ).fetchall()
        result: Dict[str, int] = {}
        for row in rows:
            path = str(row["source_file_path"] or "")
            short_id = row["note_short_id"]
            if path and short_id is not None and path not in result:
                result[path] = int(short_id)
        return result

    def _list_global_tag_names_sync(self) -> List[str]:
        with self._connect() as conn:
            rows = conn.execute("SELECT name FROM global_tags").fetchall()
        names: List[str] = []
        seen = set()
        for row in rows:
            tag = str(row["name"] or "").strip()
            if not tag or tag in seen:
                continue
            seen.add(tag)
            names.append(tag)
        return names

    def _mark_new_tags_sync(self, tags: List[str]) -> None:
        normalized = self._normalize_tags(tags)
        if not normalized:
            return
        with self._lock:
            new_tags = [tag for tag in normalized if tag not in self._tag_names]
            if not new_tags:
                return
            self._tag_names.update(new_tags)

    def upsert_user(self, platform: str, user_id: str, user_name: str = "") -> None:
        """登记用户到账本：平台 + 用户 ID 复合主键，同记录合并昵称列表（去重）。

        统一拒绝占位身份（空、0、none、null、unknown/user/assistant），
        与 _is_valid_user_id 及 deepmind 登记处共用同一集合。
        """
        plat = str(platform or "").strip()
        uid = str(user_id or "").strip()
        invalid_ids = {"", "0", "unknown", "user", "assistant", "none", "null"}
        if not plat or uid.lower() in invalid_ids:
            return
        name = str(user_name or "").strip()
        now = time.time()
        with self._lock:
            with self._connect() as conn:
                row = conn.execute(
                    "SELECT user_names FROM user_ledger WHERE platform = ? AND user_id = ?",
                    (plat, uid),
                ).fetchone()
                if row is None:
                    names = [name] if name else []
                    conn.execute(
                        "INSERT INTO user_ledger (platform, user_id, user_names, first_seen_at, last_seen_at) "
                        "VALUES (?, ?, ?, ?, ?)",
                        (plat, uid, json.dumps(names, ensure_ascii=False), now, now),
                    )
                    return
                try:
                    names = json.loads(str(row["user_names"] or "[]"))
                except (json.JSONDecodeError, ValueError):
                    names = []
                if not isinstance(names, list):
                    names = []
                if name and name not in names:
                    names.append(name)
                conn.execute(
                    "UPDATE user_ledger SET user_names = ?, last_seen_at = ? "
                    "WHERE platform = ? AND user_id = ?",
                    (json.dumps(names, ensure_ascii=False), now, plat, uid),
                )

    def get_known_user_ids(self, platform: str = "") -> List[str]:
        """返回账本中全部已知用户 ID；platform 非空时只返回该平台下的 ID。

        不带平台时返回跨平台去重后的 ID 集合（仅用于画像判定锚点），
        带平台时返回该平台下的完整列表（可能含不同用户同号，但同平台内唯一）。
        """
        plat = str(platform or "").strip()
        with self._connect() as conn:
            if plat:
                rows = conn.execute(
                    "SELECT user_id FROM user_ledger WHERE platform = ?",
                    (plat,),
                ).fetchall()
            else:
                rows = conn.execute("SELECT user_id FROM user_ledger").fetchall()
        ids = [str(row["user_id"] or "").strip() for row in rows if str(row["user_id"] or "").strip()]
        if plat:
            return ids
        seen = set()
        unique = []
        for uid in ids:
            if uid not in seen:
                seen.add(uid)
                unique.append(uid)
        return unique

    def get_user_names(self, platform: str, user_id: str) -> List[str]:
        """返回某平台下某用户账本中登记过的全部昵称。"""
        plat = str(platform or "").strip()
        uid = str(user_id or "").strip()
        if not plat or not uid:
            return []
        with self._connect() as conn:
            row = conn.execute(
                "SELECT user_names FROM user_ledger WHERE platform = ? AND user_id = ?",
                (plat, uid),
            ).fetchone()
        if row is None:
            return []
        try:
            names = json.loads(str(row["user_names"] or "[]"))
        except (json.JSONDecodeError, ValueError):
            return []
        if not isinstance(names, list):
            return []
        return [str(name).strip() for name in names if isinstance(name, str) and str(name).strip()]

    def upsert_group(self, group_id: str, group_name: str = "") -> None:
        """登记群聊到群账本：同群 ID 更新群名（用最近拿到的值）与最近活跃时间。"""
        gid = str(group_id or "").strip()
        if not gid or gid in {"Unknown", "unknown", "0"}:
            return
        gname = str(group_name or "").strip()
        now = time.time()
        with self._lock:
            with self._connect() as conn:
                row = conn.execute(
                    "SELECT group_name FROM group_ledger WHERE group_id = ?",
                    (gid,),
                ).fetchone()
                if row is None:
                    conn.execute(
                        "INSERT INTO group_ledger (group_id, group_name, first_seen_at, last_seen_at) "
                        "VALUES (?, ?, ?, ?)",
                        (gid, gname, now, now),
                    )
                    return
                if gname:
                    conn.execute(
                        "UPDATE group_ledger SET group_name = ?, last_seen_at = ? WHERE group_id = ?",
                        (gname, now, gid),
                    )
                else:
                    conn.execute(
                        "UPDATE group_ledger SET last_seen_at = ? WHERE group_id = ?",
                        (now, gid),
                    )

    def get_known_group_ids(self) -> List[str]:
        """返回群账本中全部已知群 ID。"""
        with self._connect() as conn:
            rows = conn.execute("SELECT group_id FROM group_ledger").fetchall()
        return [str(row["group_id"] or "").strip() for row in rows if str(row["group_id"] or "").strip()]

    def get_group_name(self, group_id: str) -> str:
        """返回某群的群名，未登记或无名返回空串。"""
        gid = str(group_id or "").strip()
        if not gid:
            return ""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT group_name FROM group_ledger WHERE group_id = ?",
                (gid,),
            ).fetchone()
        if row is None:
            return ""
        return str(row["group_name"] or "").strip()

    def _list_memory_rows_for_fts_sync(self) -> List[Dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT
                    mr.id,
                    mr.judgment,
                    IFNULL(tags.tags_text, '') AS tags_text
                FROM memory_records mr
                LEFT JOIN (
                    SELECT
                        mtr.memory_id AS memory_id,
                        GROUP_CONCAT(gt.name, ', ') AS tags_text
                    FROM memory_tag_rel mtr
                    JOIN global_tags gt ON gt.id = mtr.tag_id
                    GROUP BY mtr.memory_id
                ) tags ON tags.memory_id = mr.id
                """
            ).fetchall()
        result: List[Dict[str, Any]] = []
        for row in rows:
            tags = [t.strip() for t in str(row["tags_text"] or "").split(",") if t.strip()]
            result.append(
                {
                    "id": str(row["id"] or ""),
                    "judgment": str(row["judgment"] or ""),
                    "tags": tags,
                }
            )
        return [r for r in result if r["id"]]

    def _ensure_fts_ready_sync(self, force_rebuild: bool = False) -> None:
        rebuilt = False
        with self._fts_lock:
            effective_force_rebuild = bool(force_rebuild or self._fts_rebuild_required)
            if self._fts_ready and not effective_force_rebuild:
                return
            if not effective_force_rebuild and self._fts_retriever.memory_index_reusable:
                self._fts_ready = True
                self.logger.info("[检索索引] 复用已有索引 跳过重建")
                return
            previous_ready = self._fts_ready
            try:
                self._fts_retriever.rebuild_memory(self._list_memory_rows_for_fts_sync())
                self._fts_ready = True
                self._fts_rebuild_required = False
                rebuilt = True
            except Exception as e:
                self._fts_ready = previous_ready
                self.logger.error(f"[FTS5重建] 失败，异常={e}", exc_info=True)
                raise
        if rebuilt:
            self._log_fts_index_size_sync()

    def _log_fts_index_size_sync(self) -> None:
        """输出检索索引构建后的体积信息。"""
        db_size_bytes = 0
        try:
            db_size_bytes = int(self.db_path.stat().st_size)
        except Exception:
            db_size_bytes = 0

        db_size_mb = db_size_bytes / (1024 * 1024)
        self.logger.info(
            f"[检索索引] 完成 db_size={db_size_bytes}B ({db_size_mb:.2f}MB)"
        )

    def _sync_memory_fts_by_id_sync(self, memory_id: str) -> None:
        if not self._fts_ready:
            return
        mid = str(memory_id or "").strip()
        if not mid:
            return
        memories = self._get_memories_by_ids_sync([mid])
        if not memories:
            self._fts_retriever.delete_memory(mid)
            return
        mem = memories[0]
        self._fts_retriever.upsert_memory(
            item_id=mem.id,
            tags=getattr(mem, "tags", []) or [],
            judgment=str(getattr(mem, "judgment", "") or ""),
        )

    def _sync_memory_fts_batch_sync(
        self,
        upsert_ids: Optional[List[str]] = None,
        delete_ids: Optional[List[str]] = None,
    ) -> None:
        if not self._fts_ready:
            return
        upsert_list = [str(x).strip() for x in (upsert_ids or []) if str(x).strip()]
        delete_list = [str(x).strip() for x in (delete_ids or []) if str(x).strip()]
        if delete_list:
            for memory_id in delete_list:
                self._fts_retriever.delete_memory(memory_id)
        for memory_id in upsert_list:
            self._sync_memory_fts_by_id_sync(memory_id)

    async def audit_and_repair_fts_indexes(self, sample_size: int = 50) -> Dict[str, Any]:
        return await asyncio.to_thread(self._audit_and_repair_fts_indexes_sync, sample_size)

    def _audit_and_repair_fts_indexes_sync(self, sample_size: int = 50) -> Dict[str, Any]:
        del sample_size
        self._ensure_fts_ready_sync(force_rebuild=True)
        with self._connect() as conn:
            sql_memory_count = int(conn.execute("SELECT COUNT(1) FROM memory_records").fetchone()[0] or 0)
        self.logger.info(
            "[检索巡检] 完成 "
            f"memory_sql={sql_memory_count} auto_repaired=是"
        )
        return {
            "memory_sql_count": sql_memory_count,
            "memory_fts_count": -1,
            "auto_repaired": True,
        }

    @staticmethod
    def _normalize_scope(memory_scope: str) -> str:
        scope = str(memory_scope or "").strip()
        if not scope:
            raise ValidationError("memory_scope 为空，拒绝执行")
        return scope

    @staticmethod
    def _normalize_tags(tags: Iterable[str]) -> List[str]:
        normalized: List[str] = []
        seen = set()
        for tag in tags or []:
            t = str(tag).strip()
            if not t or t in seen:
                continue
            seen.add(t)
            normalized.append(t)
        return normalized

    @staticmethod
    def _to_memory_type(memory_type: str) -> MemoryType:
        raw = str(memory_type or "").strip()
        mapping = {
            "knowledge": MemoryType.KNOWLEDGE,
            "event": MemoryType.EVENT,
            "skill": MemoryType.SKILL,
            "task": MemoryType.TASK,
            "emotional": MemoryType.EMOTIONAL,
        }
        if raw in mapping:
            return mapping[raw]
        try:
            return MemoryType(raw)
        except ValueError:
            return MemoryType.KNOWLEDGE

    @staticmethod
    def _scope_sql(memory_scope: str, alias: str = "mr") -> Tuple[str, List[str]]:
        scope = MemorySqlManager._normalize_scope(memory_scope)
        if scope == "public":
            return f"{alias}.memory_scope = ?", ["public"]
        return f"({alias}.memory_scope = ? OR {alias}.memory_scope = 'public')", [scope]

    @staticmethod
    def _is_scope_allowed(memory_scope: str, target_scope: str) -> bool:
        scope = str(memory_scope or "").strip() or "public"
        target = str(target_scope or "").strip()
        if target == "public":
            return scope == "public"
        return scope in {target, "public"}

    @staticmethod
    def _row_to_memory(row: sqlite3.Row, tags: List[str]) -> BaseMemory:
        keys = set(row.keys()) if hasattr(row, "keys") else set()

        def _v(name: str, default: Any) -> Any:
            if keys and name in keys:
                return row[name]
            return default

        return BaseMemory(
            memory_type=MemorySqlManager._to_memory_type(row["memory_type"]),
            judgment=row["judgment"],
            reasoning=row["reasoning"],
            tags=tags,
            id=row["id"],
            strength=int(row["strength"]),
            is_active=bool(row["is_active"]),
            created_at=float(row["created_at"]),
            memory_scope=row["memory_scope"],
            useful_count=int(_v("useful_count", 0) or 0),
            useful_score=float(_v("useful_score", 0.0) or 0.0),
            last_recalled_at=float(_v("last_recalled_at", 0.0) or 0.0),
        )

    def _fetch_tags_for_memory_ids(
        self, conn: sqlite3.Connection, memory_ids: Sequence[str]
    ) -> Dict[str, List[str]]:
        if not memory_ids:
            return {}
        placeholders = ",".join(["?" for _ in memory_ids])
        sql = f"""
            SELECT mtr.memory_id AS memory_id, mt.name AS tag_name
            FROM memory_tag_rel mtr
            JOIN global_tags mt ON mt.id = mtr.tag_id
            WHERE mtr.memory_id IN ({placeholders})
        """
        rows = conn.execute(sql, tuple(memory_ids)).fetchall()
        result: Dict[str, List[str]] = {mid: [] for mid in memory_ids}
        for row in rows:
            memory_id = str(row["memory_id"])
            tag_name = str(row["tag_name"])
            result.setdefault(memory_id, []).append(tag_name)
        return result

    def _upsert_tags_and_bind(
        self, conn: sqlite3.Connection, memory_id: str, tags: List[str]
    ) -> None:
        if tags:
            conn.executemany(
                "INSERT OR IGNORE INTO global_tags(name) VALUES (?)",
                [(tag,) for tag in tags],
            )
            placeholders = ",".join(["?" for _ in tags])
            rows = conn.execute(
                f"SELECT id, name FROM global_tags WHERE name IN ({placeholders})",
                tuple(tags),
            ).fetchall()
            tag_id_by_name = {str(row["name"]): int(row["id"]) for row in rows}

            rel_rows = [
                (memory_id, tag_id_by_name[tag])
                for tag in tags
                if tag in tag_id_by_name
            ]
            if rel_rows:
                conn.executemany(
                    "INSERT OR IGNORE INTO memory_tag_rel(memory_id, tag_id) VALUES (?, ?)",
                    rel_rows,
                )
            self._mark_new_tags_sync(tags)

    def _replace_memory_tags(
        self, conn: sqlite3.Connection, memory_id: str, tags: List[str]
    ) -> None:
        conn.execute("DELETE FROM memory_tag_rel WHERE memory_id = ?", (memory_id,))
        self._upsert_tags_and_bind(conn, memory_id, tags)

    def _get_or_create_tag_ids_sync(self, tag_names: List[str]) -> List[int]:
        normalized = self._normalize_tags(tag_names)
        if not normalized:
            return []
        with self._connect() as conn:
            conn.executemany(
                "INSERT OR IGNORE INTO global_tags(name) VALUES (?)",
                [(tag,) for tag in normalized],
            )
            placeholders = ",".join(["?" for _ in normalized])
            rows = conn.execute(
                f"SELECT id, name FROM global_tags WHERE name IN ({placeholders})",
                tuple(normalized),
            ).fetchall()
        self._mark_new_tags_sync(normalized)
        by_name = {str(row["name"]): int(row["id"]) for row in rows}
        return [by_name[tag] for tag in normalized if tag in by_name]

    def _get_or_create_tag_ids_with_conn(
        self, conn: sqlite3.Connection, tag_names: List[str]
    ) -> List[int]:
        normalized = self._normalize_tags(tag_names)
        if not normalized:
            return []
        conn.executemany(
            "INSERT OR IGNORE INTO global_tags(name) VALUES (?)",
            [(tag,) for tag in normalized],
        )
        placeholders = ",".join(["?" for _ in normalized])
        rows = conn.execute(
            f"SELECT id, name FROM global_tags WHERE name IN ({placeholders})",
            tuple(normalized),
        ).fetchall()
        self._mark_new_tags_sync(normalized)
        by_name = {str(row["name"]): int(row["id"]) for row in rows}
        return [by_name[tag] for tag in normalized if tag in by_name]

    async def get_or_create_tag_ids(self, tag_names: List[str]) -> List[int]:
        return await asyncio.to_thread(self._get_or_create_tag_ids_sync, tag_names)

    @staticmethod
    def _alloc_next_note_short_id(conn: sqlite3.Connection) -> int:
        row = conn.execute(
            "SELECT next_id FROM note_short_id_seq WHERE id = 1"
        ).fetchone()
        next_id = int(row["next_id"]) if row else 0
        conn.execute(
            "UPDATE note_short_id_seq SET next_id = ? WHERE id = 1",
            (next_id + 1,),
        )
        return next_id

    async def clear_note_file_registry(self) -> Dict[str, int]:
        return await asyncio.to_thread(self._clear_note_file_registry_sync)

    def _clear_note_file_registry_sync(self) -> Dict[str, int]:
        with self._connect() as conn:
            count = int(conn.execute("SELECT COUNT(1) FROM note_index_records").fetchone()[0] or 0)
            conn.execute("DELETE FROM note_index_records")
            conn.execute("UPDATE note_short_id_seq SET next_id = 0 WHERE id = 1")
            conn.commit()
        return {"deleted": count}

    async def upsert_note_file_entry(
        self,
        file_id: str,
        source_file_path: str,
        heading_h1: str = "",
        total_lines: int = 0,
        updated_at: Optional[float] = None,
    ) -> Dict[str, int]:
        return await asyncio.to_thread(
            self._upsert_note_file_entry_sync,
            file_id,
            source_file_path,
            heading_h1,
            total_lines,
            updated_at,
        )

    def _upsert_note_file_entry_sync(
        self,
        file_id: str,
        source_file_path: str,
        heading_h1: str = "",
        total_lines: int = 0,
        updated_at: Optional[float] = None,
    ) -> Dict[str, int]:
        fid = str(file_id or "").strip()
        rel_path = str(source_file_path or "").replace("\\", "/").strip().lstrip("/")
        heading_1 = str(heading_h1 or "").strip()
        if not fid or not rel_path:
            return {"scanned": 1, "upserted": 0, "failed": 1}

        source_id = f"note_file_{fid}"
        with self._connect() as conn:
            existing = conn.execute(
                "SELECT note_short_id FROM note_index_records WHERE source_id = ?",
                (source_id,),
            ).fetchone()
            if existing and existing["note_short_id"] is not None:
                note_short_id = int(existing["note_short_id"])
            else:
                legacy = conn.execute(
                    """
                    SELECT note_short_id
                    FROM note_index_records
                    WHERE source_file_path = ? AND note_short_id IS NOT NULL
                    ORDER BY note_short_id ASC
                    LIMIT 1
                    """,
                    (rel_path,),
                ).fetchone()
                if legacy and legacy["note_short_id"] is not None:
                    note_short_id = int(legacy["note_short_id"])
                else:
                    note_short_id = self._alloc_next_note_short_id(conn)

            conn.execute(
                """
                DELETE FROM note_index_records
                WHERE (file_id = ? OR source_file_path = ?) AND source_id <> ?
                """,
                (fid, rel_path, source_id),
            )
            conn.execute(
                """
                INSERT INTO note_index_records(
                    source_id, note_short_id, file_id, source_file_path,
                    heading_h1, heading_h2, heading_h3,
                    heading_h4, heading_h5, heading_h6,
                    total_lines, updated_at
                ) VALUES (?, ?, ?, ?, ?, '', '', '', '', '', ?, ?)
                ON CONFLICT(source_id) DO UPDATE SET
                    note_short_id=excluded.note_short_id,
                    file_id=excluded.file_id,
                    source_file_path=excluded.source_file_path,
                    heading_h1=excluded.heading_h1,
                    heading_h2='',
                    heading_h3='',
                    heading_h4='',
                    heading_h5='',
                    heading_h6='',
                    total_lines=excluded.total_lines,
                    updated_at=excluded.updated_at
                """,
                (
                    source_id,
                    note_short_id,
                    fid,
                    rel_path,
                    heading_1,
                    int(total_lines or 0),
                    float(updated_at or time.time()),
                ),
            )
            conn.commit()
        return {"scanned": 1, "upserted": 1, "failed": 0}

    async def delete_note_index_by_file_id(self, file_id: str) -> List[str]:
        return await asyncio.to_thread(self._delete_note_index_by_file_id_sync, file_id)

    def _delete_note_index_by_file_id_sync(self, file_id: str) -> List[str]:
        fid = str(file_id or "").strip()
        if not fid:
            return []
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT source_id FROM note_index_records WHERE file_id = ?",
                (fid,),
            ).fetchall()
            source_ids = [str(row["source_id"]) for row in rows]
            conn.execute("DELETE FROM note_index_records WHERE file_id = ?", (fid,))
            conn.commit()
        return source_ids

    def _build_memory_doc_text_map_by_ids(self, memory_ids: List[str]) -> Dict[str, str]:
        memories = self._get_memories_by_ids_sync(memory_ids)
        memory_map = {mem.id: mem for mem in memories}
        doc_text_map: Dict[str, str] = {}
        for memory_id in memory_ids:
            mem = memory_map.get(str(memory_id))
            if mem is None:
                continue
            tags = " ".join(
                [str(t).strip() for t in (getattr(mem, "tags", []) or []) if str(t).strip()]
            )
            doc_text_map[str(memory_id)] = (
                f"{getattr(mem, 'judgment', '')}\n{getattr(mem, 'reasoning', '')}\n{tags}"
            ).strip()
        return doc_text_map

    async def get_note_index_by_short_id(self, note_short_id: int) -> Optional[Dict[str, Any]]:
        return await asyncio.to_thread(self._get_note_index_by_short_id_sync, note_short_id)

    def _get_note_index_by_short_id_sync(self, note_short_id: int) -> Optional[Dict[str, Any]]:
        sid = int(note_short_id)
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT
                    nir.source_id,
                    nir.note_short_id,
                    nir.file_id,
                    nir.source_file_path,
                    nir.heading_h1,
                    nir.heading_h2,
                    nir.heading_h3,
                    nir.heading_h4,
                    nir.heading_h5,
                    nir.heading_h6,
                    nir.total_lines,
                    nir.updated_at
                FROM note_index_records nir
                WHERE nir.note_short_id = ?
                LIMIT 1
                """,
                (sid,),
            ).fetchone()
        return dict(row) if row else None

    async def find_matched_tag_ids(self, query_text: str) -> List[int]:
        return await asyncio.to_thread(self._find_matched_tag_ids_sync, query_text)

    def _find_matched_tag_ids_sync(self, query_text: str) -> List[int]:
        text = str(query_text or "")
        if not text.strip():
            return []
        with self._lock:
            matched_names = [name for name in self._tag_names if name and name in text]
        if not matched_names:
            return []
        placeholders = ",".join(["?" for _ in matched_names])
        with self._connect() as conn:
            rows = conn.execute(
                f"SELECT id FROM global_tags WHERE name IN ({placeholders})",
                tuple(matched_names),
            ).fetchall()
        return [int(row["id"]) for row in rows]

    async def search_memory_ids_by_tag_ids(self, tag_ids: List[int]) -> List[str]:
        return await asyncio.to_thread(self._search_memory_ids_by_tag_ids_sync, tag_ids)

    def _search_memory_ids_by_tag_ids_sync(self, tag_ids: List[int]) -> List[str]:
        ids = [int(tid) for tid in (tag_ids or [])]
        if not ids:
            return []
        placeholders = ",".join(["?" for _ in ids])
        with self._connect() as conn:
            rows = conn.execute(
                f"""
                SELECT memory_id
                FROM memory_tag_rel
                WHERE tag_id IN ({placeholders})
                GROUP BY memory_id
                ORDER BY COUNT(DISTINCT tag_id) DESC
                """,
                tuple(ids),
            ).fetchall()
        return [str(row["memory_id"]) for row in rows]

    async def unified_tag_hit_search(self, query_text: str) -> Dict[str, Any]:
        """
        统一 tags 命中入口：一次解析，返回命中 tag_ids + 记忆ID。
        """
        return await asyncio.to_thread(self._unified_tag_hit_search_sync, query_text)

    def _unified_tag_hit_search_sync(self, query_text: str) -> Dict[str, Any]:
        tag_ids = self._find_matched_tag_ids_sync(query_text)
        memory_ids = self._search_memory_ids_by_tag_ids_sync(tag_ids)
        return {
            "tag_ids": tag_ids,
            "memory_ids": memory_ids,
            "note_source_ids": [],
        }

    async def remember(
        self,
        memory_type: str,
        judgment: str,
        reasoning: str,
        tags: List[str],
        is_active: bool = False,
        strength: Optional[int] = None,
        memory_scope: str = "public",
    ) -> BaseMemory:
        return await asyncio.to_thread(
            self._remember_sync,
            memory_type,
            judgment,
            reasoning,
            tags,
            is_active,
            strength,
            memory_scope,
        )

    async def upsert_memory(self, memory: BaseMemory) -> BaseMemory:
        """
        用指定ID将记忆写入中央库（用于向量模式镜像写入）。
        """
        return await asyncio.to_thread(self._upsert_memory_sync, memory)

    def _remember_sync(
        self,
        memory_type: str,
        judgment: str,
        reasoning: str,
        tags: List[str],
        is_active: bool = False,
        strength: Optional[int] = None,
        memory_scope: str = "public",
    ) -> BaseMemory:
        scope = self._normalize_scope(memory_scope)
        normalized_tags = self._normalize_tags(tags)
        now = time.time()
        memory = BaseMemory(
            memory_type=self._to_memory_type(memory_type),
            judgment=str(judgment or "").strip(),
            reasoning=str(reasoning or "").strip(),
            tags=normalized_tags,
            id=str(uuid.uuid4()),
            strength=int(
                strength
                if strength is not None
                else system_config.default_passive_strength
            ),
            is_active=bool(is_active),
            created_at=now,
            memory_scope=scope,
            useful_count=0,
            useful_score=0.0,
            last_recalled_at=0.0,
        )

        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO memory_records(
                    id, memory_type, judgment, reasoning, strength, is_active,
                    useful_count, useful_score, last_recalled_at,
                    memory_scope, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    memory.id,
                    memory.memory_type.value,
                    memory.judgment,
                    memory.reasoning,
                    memory.strength,
                    1 if memory.is_active else 0,
                    memory.useful_count,
                    memory.useful_score,
                    memory.last_recalled_at,
                    scope,
                    memory.created_at,
                    now,
                ),
            )
            self._upsert_tags_and_bind(conn, memory.id, normalized_tags)
            conn.commit()
        self._sync_memory_fts_by_id_sync(memory.id)
        self.register_short_id(memory.id)

        return memory

    def _upsert_memory_sync(self, memory: BaseMemory) -> BaseMemory:
        scope = self._normalize_scope(getattr(memory, "memory_scope", "public"))
        normalized_tags = self._normalize_tags(getattr(memory, "tags", []))
        now = time.time()
        memory_id = str(getattr(memory, "id", "") or uuid.uuid4())
        created_at = float(getattr(memory, "created_at", now) or now)
        memory_type = getattr(getattr(memory, "memory_type", None), "value", None)
        if not memory_type:
            memory_type = "知识记忆"

        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO memory_records(
                    id, memory_type, judgment, reasoning, strength, is_active,
                    useful_count, useful_score, last_recalled_at,
                    memory_scope, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    memory_type=excluded.memory_type,
                    judgment=excluded.judgment,
                    reasoning=excluded.reasoning,
                    strength=excluded.strength,
                    is_active=excluded.is_active,
                    useful_count=excluded.useful_count,
                    useful_score=excluded.useful_score,
                    last_recalled_at=excluded.last_recalled_at,
                    memory_scope=excluded.memory_scope,
                    created_at=excluded.created_at,
                    updated_at=excluded.updated_at
                """,
                (
                    memory_id,
                    str(memory_type),
                    str(getattr(memory, "judgment", "") or "").strip(),
                    str(getattr(memory, "reasoning", "") or "").strip(),
                    int(getattr(memory, "strength", 1) or 1),
                    1 if bool(getattr(memory, "is_active", False)) else 0,
                    int(getattr(memory, "useful_count", 0) or 0),
                    float(getattr(memory, "useful_score", 0.0) or 0.0),
                    float(getattr(memory, "last_recalled_at", 0.0) or 0.0),
                    scope,
                    created_at,
                    now,
                ),
            )
            self._replace_memory_tags(conn, memory_id, normalized_tags)
            conn.commit()
        self._sync_memory_fts_by_id_sync(memory_id)
        self.register_short_id(memory_id)
        return memory

    async def upsert_memories_by_judgment(self, memories: List[Dict[str, Any]]) -> Dict[str, int]:
        return await asyncio.to_thread(self._upsert_memories_by_judgment_sync, memories)

    def _upsert_memories_by_judgment_sync(self, memories: List[Dict[str, Any]]) -> Dict[str, int]:
        """
        按 judgment 幂等写入（同 judgment 仅保留最新 created_at）。

        Returns:
            {"scanned": int, "deduped": int, "upserted": int, "failed": int}
        """
        scanned = len(memories or [])
        deduped_map: Dict[str, Dict[str, Any]] = {}
        failed = 0

        for item in memories or []:
            judgment = str(item.get("judgment") or "").strip()
            if not judgment:
                continue
            try:
                created_at = float(item.get("created_at") or 0)
            except (TypeError, ValueError):
                created_at = 0.0

            current = deduped_map.get(judgment)
            if current is None:
                deduped_map[judgment] = dict(item)
                deduped_map[judgment]["created_at"] = created_at
                continue

            current_created = float(current.get("created_at") or 0)
            if created_at >= current_created:
                deduped_map[judgment] = dict(item)
                deduped_map[judgment]["created_at"] = created_at

        upserted = 0
        now = time.time()
        fts_upsert_ids: List[str] = []
        fts_delete_ids: List[str] = []

        with self._connect() as conn:
            for judgment, raw in deduped_map.items():
                try:
                    created_at = float(raw.get("created_at") or now)
                    normalized_tags = self._normalize_tags(BaseMemory._parse_tags(raw.get("tags", [])))
                    reasoning = str(raw.get("reasoning") or "").strip()
                    memory_type = str(raw.get("memory_type") or "知识记忆").strip() or "知识记忆"
                    strength = int(raw.get("strength", 1) or 1)
                    is_active = 1 if bool(raw.get("is_active", False)) else 0
                    useful_count = int(raw.get("useful_count", 0) or 0)
                    useful_score = float(raw.get("useful_score", 0.0) or 0.0)
                    last_recalled_at = float(raw.get("last_recalled_at", 0.0) or 0.0)
                    memory_scope = self._normalize_scope(raw.get("memory_scope", "public"))

                    existing_rows = conn.execute(
                        """
                        SELECT id, created_at
                        FROM memory_records
                        WHERE judgment = ?
                        ORDER BY created_at DESC, updated_at DESC
                        """,
                        (judgment,),
                    ).fetchall()

                    if existing_rows:
                        keep_id = str(existing_rows[0]["id"])
                        existing_created_at = float(existing_rows[0]["created_at"] or 0)
                        if created_at >= existing_created_at:
                            conn.execute(
                                """
                                UPDATE memory_records
                                SET memory_type = ?,
                                    reasoning = ?,
                                    strength = ?,
                                    is_active = ?,
                                    useful_count = ?,
                                    useful_score = ?,
                                    last_recalled_at = ?,
                                    memory_scope = ?,
                                    created_at = ?,
                                    updated_at = ?
                                WHERE id = ?
                                """,
                                (
                                    memory_type,
                                    reasoning,
                                    strength,
                                    is_active,
                                    useful_count,
                                    useful_score,
                                    last_recalled_at,
                                    memory_scope,
                                    created_at,
                                    now,
                                    keep_id,
                                ),
                            )
                            self._replace_memory_tags(conn, keep_id, normalized_tags)
                            upserted += 1
                            fts_upsert_ids.append(keep_id)

                        duplicate_ids = [str(row["id"]) for row in existing_rows[1:]]
                        if duplicate_ids:
                            placeholders = ",".join(["?" for _ in duplicate_ids])
                            conn.execute(
                                f"DELETE FROM memory_records WHERE id IN ({placeholders})",
                                tuple(duplicate_ids),
                            )
                            conn.execute(
                                f"DELETE FROM memory_tag_rel WHERE memory_id IN ({placeholders})",
                                tuple(duplicate_ids),
                            )
                            fts_delete_ids.extend(duplicate_ids)
                    else:
                        # 中央记忆库ID必须由本项目生成，禁止复用外部传入ID。
                        memory_id = str(uuid.uuid4())
                        conn.execute(
                            """
                            INSERT INTO memory_records(
                                id, memory_type, judgment, reasoning, strength, is_active,
                                useful_count, useful_score, last_recalled_at,
                                memory_scope, created_at, updated_at
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            """,
                            (
                                memory_id,
                                memory_type,
                                judgment,
                                reasoning,
                                strength,
                                is_active,
                                useful_count,
                                useful_score,
                                last_recalled_at,
                                memory_scope,
                                created_at,
                                now,
                            ),
                        )
                        self._replace_memory_tags(conn, memory_id, normalized_tags)
                        upserted += 1
                        fts_upsert_ids.append(memory_id)

                except Exception:
                    failed += 1
                    self.logger.exception("SimpleMemory 备份写入失败 (judgment=%s)", judgment)

            conn.execute(
                """
                DELETE FROM memory_tag_rel
                WHERE memory_id NOT IN (SELECT id FROM memory_records)
                """
            )
            conn.commit()
        self._sync_memory_fts_batch_sync(
            upsert_ids=fts_upsert_ids,
            delete_ids=fts_delete_ids,
        )

        return {
            "scanned": scanned,
            "deduped": len(deduped_map),
            "upserted": upserted,
            "failed": failed,
        }

    async def list_all_memories_for_vector_sync(self) -> List[Dict[str, Any]]:
        """导出 simple 库全部记忆（含 tags）用于向量回灌。"""
        return await asyncio.to_thread(self._list_all_memories_for_vector_sync_sync)

    def list_all_memory_ids_sync(self) -> List[str]:
        """同步获取全库所有记忆 ID（用于启动时构建短 ID 注册表）。"""
        with self._connect() as conn:
            rows = conn.execute("SELECT id FROM memory_records ORDER BY created_at ASC").fetchall()
        return [str(row["id"]) for row in rows if row["id"]]

    def _list_all_memories_for_vector_sync_sync(self) -> List[Dict[str, Any]]:
        with self._connect() as conn:
            sql = """
                SELECT
                    mr.id,
                    mr.memory_type,
                    mr.judgment,
                    mr.reasoning,
                    mr.strength,
                    mr.is_active,
                    mr.useful_count,
                    mr.useful_score,
                    mr.last_recalled_at,
                    mr.memory_scope,
                    mr.created_at,
                    IFNULL(tags.tags_text, '') AS tags
                FROM memory_records mr
                LEFT JOIN (
                    SELECT
                        mtr.memory_id AS memory_id,
                        GROUP_CONCAT(mt.name, ', ') AS tags_text
                    FROM memory_tag_rel mtr
                    JOIN global_tags mt ON mt.id = mtr.tag_id
                    GROUP BY mtr.memory_id
                ) tags ON tags.memory_id = mr.id
                ORDER BY mr.created_at DESC
            """
            rows = conn.execute(sql).fetchall()

        records: List[Dict[str, Any]] = []
        for row in rows:
            records.append(
                {
                    "id": row["id"],
                    "memory_type": row["memory_type"],
                    "judgment": row["judgment"],
                    "reasoning": row["reasoning"],
                    "strength": int(row["strength"] or 1),
                    "is_active": bool(row["is_active"]),
                    "useful_count": int(row["useful_count"] or 0),
                    "useful_score": float(row["useful_score"] or 0.0),
                    "last_recalled_at": float(row["last_recalled_at"] or 0.0),
                    "memory_scope": row["memory_scope"] or "public",
                    "created_at": float(row["created_at"] or 0),
                    "tags": BaseMemory._parse_tags(row["tags"] or ""),
                }
            )
        return records

    @staticmethod
    def build_vector_text(judgment: str, tags: List[str]) -> str:
        """构建轻量向量索引文本。"""
        safe_judgment = str(judgment or "").strip()
        safe_tags = [str(tag).strip() for tag in (tags or []) if str(tag).strip()]
        if safe_tags:
            return f"{safe_judgment} {' '.join(safe_tags)}".strip()
        return safe_judgment

    async def list_memory_index_rows(self) -> List[Dict[str, str]]:
        """
        导出记忆轻量向量索引数据（仅 id + vector_text）。
        """
        return await asyncio.to_thread(self._list_memory_index_rows_sync)

    def _list_memory_index_rows_sync(self) -> List[Dict[str, str]]:
        with self._connect() as conn:
            sql = """
                SELECT
                    mr.id,
                    mr.judgment,
                    IFNULL(tags.tags_text, '') AS tags
                FROM memory_records mr
                LEFT JOIN (
                    SELECT
                        mtr.memory_id AS memory_id,
                        GROUP_CONCAT(gt.name, ' ') AS tags_text
                    FROM memory_tag_rel mtr
                    JOIN global_tags gt ON gt.id = mtr.tag_id
                    GROUP BY mtr.memory_id
                ) tags ON tags.memory_id = mr.id
            """
            rows = conn.execute(sql).fetchall()

        result: List[Dict[str, str]] = []
        for row in rows:
            memory_id = str(row["id"])
            judgment = str(row["judgment"] or "")
            tag_tokens = [t for t in str(row["tags"] or "").split(" ") if t]
            vector_text = self.build_vector_text(judgment, tag_tokens)
            if not vector_text:
                continue
            result.append({"id": memory_id, "vector_text": vector_text})
        return result

    async def export_backup_snapshot(self) -> Dict[str, Any]:
        """导出中央记忆库快照（JSON冷备份使用）。"""
        return await asyncio.to_thread(self._export_backup_snapshot_sync)

    def _export_backup_snapshot_sync(self) -> Dict[str, Any]:
        with self._connect() as conn:
            records_rows = conn.execute(
                """
                SELECT id, memory_type, judgment, reasoning, strength, is_active,
                       useful_count, useful_score, last_recalled_at,
                       last_decay_at, memory_scope, created_at, updated_at
                FROM memory_records
                ORDER BY created_at DESC
                """
            ).fetchall()
            tags_rows = conn.execute(
                "SELECT id, name FROM global_tags ORDER BY id ASC"
            ).fetchall()
            rel_rows = conn.execute(
                "SELECT memory_id, tag_id FROM memory_tag_rel"
            ).fetchall()

        records = [dict(row) for row in records_rows]
        tags = [dict(row) for row in tags_rows]
        relations = [dict(row) for row in rel_rows]
        return {
            "schema_version": 1,
            "exported_at": int(time.time()),
            "records": records,
            "global_tags": tags,
            "memory_tag_rel": relations,
        }

    async def recall_by_tags(
        self,
        query: str,
        limit: int,
        memory_scope: str,
        vector_scores: Optional[Dict[str, float]] = None,
    ) -> List[BaseMemory]:
        text = str(query or "").strip()
        if not text:
            return []

        self._ensure_fts_ready_sync()
        candidate_limit = max(20, int(limit) * 20)
        bm25_limit = max(50, int(limit) * 30)
        hits = await self._hybrid_engine.search_with_strategy(
            query=text,
            limit=candidate_limit,
            candidate_limit=candidate_limit,
            bm25_limit=bm25_limit,
            vector_scores=vector_scores,
            bm25_only_search=lambda q, k: self._fts_retriever.search_memory_bm25_only(query=q, limit=k),
            fusion_search=lambda q, k, bk, scores: self._fts_retriever.search_memory(
                query=q,
                limit=k,
                fts_limit=bk,
                fts_weight=0.3,
                vector_weight=0.7,
                vector_scores=scores,
            ),
            build_doc_text_map=self._build_memory_doc_text_map_by_ids,
        )
        if not hits:
            return []

        ordered_ids = [
            str(item.get("id") or "").strip()
            for item in hits
            if str(item.get("id") or "").strip()
        ]
        score_map = {
            str(item.get("id") or "").strip(): float(item.get("final_score", 0.0))
            for item in hits
            if str(item.get("id") or "").strip()
        }
        score_kind_map = {
            str(item.get("id") or "").strip(): str(item.get("score_kind") or "normalized")
            for item in hits
            if str(item.get("id") or "").strip()
        }
        memories = self._get_memories_by_ids_sync(ordered_ids)
        memory_map = {mem.id: mem for mem in memories}

        ordered: List[BaseMemory] = []
        for memory_id in ordered_ids:
            mem = memory_map.get(memory_id)
            if mem is None:
                continue
            if not self._is_scope_allowed(getattr(mem, "memory_scope", "public"), memory_scope):
                continue
            final_score = float(score_map.get(memory_id, 0.0))
            score_kind = score_kind_map.get(memory_id, "normalized")
            if score_kind != "rrf" and final_score < 0.5:
                continue
            mem.similarity = final_score
            ordered.append(mem)
            if len(ordered) >= int(limit):
                break
        return ordered

    async def reinforce_memories(self, memory_ids: List[str], delta: int = 1) -> None:
        ids = [str(mid).strip() for mid in (memory_ids or []) if str(mid).strip()]
        if not ids:
            return
        placeholders = ",".join(["?" for _ in ids])
        now = time.time()
        score_delta = float(self.decay_policy.config.consolidate_speed)
        with self._connect() as conn:
            conn.execute(
                f"""
                UPDATE memory_records
                SET strength = strength + ?,
                    useful_count = useful_count + 1,
                    useful_score = useful_score + ?,
                    last_recalled_at = ?,
                    updated_at = ?
                WHERE id IN ({placeholders})
                """,
                tuple([int(delta), score_delta, now, now, *ids]),
            )
            conn.commit()

    async def decay_memories(self, memory_ids: List[str], delta: int = 1) -> None:
        """
        兼容旧接口：仅对 T1（待证档）执行“召回无用衰减”。
        """
        ids = [str(mid).strip() for mid in (memory_ids or []) if str(mid).strip()]
        if not ids:
            return
        placeholders = ",".join(["?" for _ in ids])
        now = time.time()
        tier1_min_score = float(self.decay_policy.config.tier0_threshold)
        tier1_max_score = float(self.decay_policy.config.tier1_threshold)
        with self._connect() as conn:
            conn.execute(
                f"""
                UPDATE memory_records
                SET strength = CASE WHEN strength - ? < 0 THEN 0 ELSE strength - ? END,
                    updated_at = ?
                WHERE id IN ({placeholders})
                  AND is_active = 0
                  AND useful_score >= ?
                  AND useful_score < ?
                """,
                tuple([int(delta), int(delta), now, tier1_min_score, tier1_max_score, *ids]),
            )
            conn.commit()

    async def decay_recalled_but_useless(self, memory_ids: List[str], delta: int = 1) -> None:
        await self.decay_memories(memory_ids, delta=delta)

    async def natural_decay_tier0(self, now_ts: Optional[float] = None) -> int:
        """
        仅对 T0（易逝档）做时间驱动遗忘。
        """
        now = float(now_ts or time.time())
        cycle_days = int(self.decay_policy.tier0_decay_cycle_days())
        cycle_seconds = float(cycle_days * 86400)
        tier0_max_score = float(self.decay_policy.config.tier0_threshold)
        with self._connect() as conn:
            # 批量计算并更新：避免逐条 Python 循环与 IO 放大。
            # ref_time 语义：
            # - 已有 last_decay_at: 续算
            # - 无 last_decay_at: 取 max(created_at, last_recalled_at)
            cur = conn.execute(
                """
                UPDATE memory_records
                SET
                    strength = CASE
                        WHEN strength - CAST((? - CASE
                            WHEN last_decay_at > 0 THEN last_decay_at
                            WHEN last_recalled_at > created_at THEN last_recalled_at
                            ELSE created_at
                        END) / ? AS INTEGER) < 0
                        THEN 0
                        ELSE strength - CAST((? - CASE
                            WHEN last_decay_at > 0 THEN last_decay_at
                            WHEN last_recalled_at > created_at THEN last_recalled_at
                            ELSE created_at
                        END) / ? AS INTEGER)
                    END,
                    last_decay_at = (
                        CASE
                            WHEN last_decay_at > 0 THEN last_decay_at
                            WHEN last_recalled_at > created_at THEN last_recalled_at
                            ELSE created_at
                        END
                    ) + (
                        CAST((? - CASE
                            WHEN last_decay_at > 0 THEN last_decay_at
                            WHEN last_recalled_at > created_at THEN last_recalled_at
                            ELSE created_at
                        END) / ? AS INTEGER) * ?
                    ),
                    updated_at = ?
                WHERE is_active = 0
                  AND useful_score < ?
                  AND strength > 0
                  AND CAST((? - CASE
                        WHEN last_decay_at > 0 THEN last_decay_at
                        WHEN last_recalled_at > created_at THEN last_recalled_at
                        ELSE created_at
                    END) / ? AS INTEGER) > 0
                """,
                (
                    now,
                    cycle_seconds,
                    now,
                    cycle_seconds,
                    now,
                    cycle_seconds,
                    cycle_seconds,
                    now,
                    tier0_max_score,
                    now,
                    cycle_seconds,
                ),
            )
            conn.commit()
            return int(cur.rowcount or 0)

    async def decay_tier0_memories(self) -> int:
        """睡眠第一步：T0 时间衰减，只降强度，不删除任何记录。"""
        return await self.natural_decay_tier0()

    def _list_retirement_candidates_sync(self) -> List[BaseMemory]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT id, memory_type, judgment, reasoning, strength,
                       is_active, useful_count, useful_score, last_recalled_at,
                       memory_scope, created_at
                FROM memory_records
                WHERE is_active = 0 AND strength <= 0
                ORDER BY created_at ASC
                """
            ).fetchall()
            tags_map = self._fetch_tags_for_memory_ids(
                conn, [str(row["id"]) for row in rows]
            )
        return [
            self._row_to_memory(row, tags_map.get(str(row["id"]), []))
            for row in rows
        ]

    async def list_retirement_candidates(self) -> List[BaseMemory]:
        """睡眠第二步：取出强度归零、等待裁决的被动记忆。"""
        return await asyncio.to_thread(self._list_retirement_candidates_sync)

    def _apply_retirement_decisions_sync(
        self,
        delete_ids: List[str],
        keep_ids: List[str],
    ) -> Dict[str, int]:
        delete_list = [str(mid).strip() for mid in (delete_ids or []) if str(mid).strip()]
        keep_list = [str(mid).strip() for mid in (keep_ids or []) if str(mid).strip()]
        deleted = 0
        promoted = 0
        deleted_ids: List[str] = []
        now = time.time()
        with self._connect() as conn:
            if delete_list:
                placeholders = ",".join(["?" for _ in delete_list])
                rows = conn.execute(
                    f"""
                    SELECT id FROM memory_records
                    WHERE id IN ({placeholders})
                      AND is_active = 0
                      AND strength <= 0
                    """,
                    tuple(delete_list),
                ).fetchall()
                deleted_ids = [str(row["id"]) for row in rows]
                if deleted_ids:
                    delete_placeholders = ",".join(["?" for _ in deleted_ids])
                    cur = conn.execute(
                        f"DELETE FROM memory_records WHERE id IN ({delete_placeholders})",
                        tuple(deleted_ids),
                    )
                    deleted = int(cur.rowcount or 0)
            if keep_list:
                placeholders = ",".join(["?" for _ in keep_list])
                cur = conn.execute(
                    f"""
                    UPDATE memory_records
                    SET is_active = 1, updated_at = ?
                    WHERE id IN ({placeholders})
                      AND is_active = 0
                    """,
                    tuple([now, *keep_list]),
                )
                promoted = int(cur.rowcount or 0)
            if delete_list:
                conn.execute(
                    """
                    DELETE FROM memory_tag_rel
                    WHERE memory_id NOT IN (SELECT id FROM memory_records)
                    """
                )
            conn.commit()
        if deleted_ids:
            self._sync_memory_fts_batch_sync(delete_ids=deleted_ids)
        return {"deleted": deleted, "promoted": promoted}

    async def apply_retirement_decisions(
        self,
        delete_ids: List[str],
        keep_ids: List[str],
    ) -> Dict[str, int]:
        """睡眠第三步：按裁决执行删除与永久化，返回实际生效条数。"""
        return await asyncio.to_thread(
            self._apply_retirement_decisions_sync,
            delete_ids,
            keep_ids,
        )

    def _get_memories_by_ids_sync(self, memory_ids: List[str]) -> List[BaseMemory]:
        ids = [str(mid).strip() for mid in (memory_ids or []) if str(mid).strip()]
        if not ids:
            return []
        placeholders = ",".join(["?" for _ in ids])
        with self._connect() as conn:
            rows = conn.execute(
                f"""
                SELECT id, memory_type, judgment, reasoning, strength,
                       is_active, useful_count, useful_score, last_recalled_at,
                       memory_scope, created_at
                FROM memory_records
                WHERE id IN ({placeholders})
                """,
                tuple(ids),
            ).fetchall()
            tags_map = self._fetch_tags_for_memory_ids(conn, [str(row["id"]) for row in rows])
        return [self._row_to_memory(row, tags_map.get(str(row["id"]), [])) for row in rows]

    async def get_memories_by_ids(self, memory_ids: List[str]) -> List[BaseMemory]:
        return await asyncio.to_thread(self._get_memories_by_ids_sync, memory_ids)

    async def recall_user_profiles(
        self,
        user_ids: List[str],
        memory_scope: str,
        limit_per_user: int = 30,
    ) -> List[BaseMemory]:
        return await asyncio.to_thread(
            self._recall_user_profiles_sync,
            user_ids,
            memory_scope,
            limit_per_user,
        )

    def _recall_user_profiles_sync(
        self,
        user_ids: List[str],
        memory_scope: str,
        limit_per_user: int = 30,
    ) -> List[BaseMemory]:
        user_tags = []
        seen_users = set()
        for raw in user_ids or []:
            user_id = str(raw or "").strip()
            if not user_id or user_id in seen_users:
                continue
            seen_users.add(user_id)
            user_tags.append(user_id)
        if not user_tags:
            return []

        # 用账本全部已知 ID 作为画像判定锚点：账本命中即 ID，不猜形态
        ledger_ids = self.get_known_user_ids()
        known_user_ids = list(dict.fromkeys([*ledger_ids, *user_tags]))

        scope_clause, scope_args = self._scope_sql(memory_scope, alias="mr")
        user_placeholders = ",".join(["?" for _ in user_tags])
        attr_tags = sorted(PROFILE_ATTRIBUTE_TAGS)
        attr_placeholders = ",".join(["?" for _ in attr_tags])

        with self._connect() as conn:
            rows = conn.execute(
                f"""
                SELECT DISTINCT mr.id
                FROM memory_records mr
                JOIN memory_tag_rel utr ON utr.memory_id = mr.id
                JOIN global_tags ugt ON ugt.id = utr.tag_id
                JOIN memory_tag_rel atr ON atr.memory_id = mr.id
                JOIN global_tags agt ON agt.id = atr.tag_id
                WHERE {scope_clause}
                  AND ugt.name IN ({user_placeholders})
                  AND agt.name IN ({attr_placeholders})
                ORDER BY mr.is_active DESC, mr.updated_at DESC, mr.created_at DESC
                """,
                tuple([*scope_args, *user_tags, *attr_tags]),
            ).fetchall()

        ordered_ids = [str(row["id"]) for row in rows]
        memories = self._get_memories_by_ids_sync(ordered_ids)
        memory_map = {
            mem.id: mem
            for mem in memories
            if is_user_profile_tags(mem.tags, known_user_ids=known_user_ids)
        }

        per_user_count = {user_id: 0 for user_id in user_tags}
        result: List[BaseMemory] = []
        for memory_id in ordered_ids:
            mem = memory_map.get(memory_id)
            if mem is None:
                continue
            matched_user = ""
            tags = set(str(tag) for tag in (mem.tags or []))
            for user_id in user_tags:
                if user_id in tags:
                    matched_user = user_id
                    break
            if not matched_user:
                continue
            if per_user_count[matched_user] >= int(limit_per_user):
                continue
            per_user_count[matched_user] += 1
            result.append(mem)
        return result

    async def merge_group(self, memory_ids: List[str]) -> Optional[BaseMemory]:
        return await asyncio.to_thread(self._merge_group_sync, memory_ids)

    def _merge_group_sync(self, memory_ids: List[str]) -> Optional[BaseMemory]:
        memories = self._get_memories_by_ids_sync(memory_ids)
        if len(memories) < 2:
            return None

        non_public_scopes = {
            str(mem.memory_scope or "public").strip()
            for mem in memories
            if str(mem.memory_scope or "public").strip() != "public"
        }
        if len(non_public_scopes) > 1:
            raise ValidationError("禁止合并不同私有分类域的记忆")

        merged_scope = next(iter(non_public_scopes), "public")
        first = memories[0]
        merged_strength = sum(mem.strength for mem in memories)
        merged_useful_count = sum(int(getattr(mem, "useful_count", 0) or 0) for mem in memories)
        merged_useful_score = max(float(getattr(mem, "useful_score", 0.0) or 0.0) for mem in memories)
        merged_last_recalled_at = max(float(getattr(mem, "last_recalled_at", 0.0) or 0.0) for mem in memories)
        now = time.time()
        new_memory = BaseMemory(
            memory_type=self._to_memory_type("knowledge"),
            judgment=first.judgment or "合并记忆",
            reasoning=first.reasoning or "合并多个相似记忆",
            tags=self._normalize_tags(first.tags),
            id=str(uuid.uuid4()),
            strength=merged_strength,
            is_active=False,
            created_at=now,
            memory_scope=merged_scope,
            useful_count=merged_useful_count,
            useful_score=merged_useful_score,
            last_recalled_at=merged_last_recalled_at,
        )

        ids = [mem.id for mem in memories]
        placeholders = ",".join(["?" for _ in ids])
        with self._lock:
            cache_snapshot = set(self._tag_names)
        with self._connect() as conn:
            try:
                conn.execute(
                    """
                    INSERT INTO memory_records(
                        id, memory_type, judgment, reasoning, strength, is_active,
                        useful_count, useful_score, last_recalled_at,
                        memory_scope, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        new_memory.id,
                        new_memory.memory_type.value,
                        new_memory.judgment,
                        new_memory.reasoning,
                        new_memory.strength,
                        1 if new_memory.is_active else 0,
                        new_memory.useful_count,
                        new_memory.useful_score,
                        new_memory.last_recalled_at,
                        new_memory.memory_scope,
                        new_memory.created_at,
                        now,
                    ),
                )
                self._upsert_tags_and_bind(conn, new_memory.id, new_memory.tags)
                conn.execute(
                    f"DELETE FROM memory_tag_rel WHERE memory_id IN ({placeholders})",
                    tuple(ids),
                )
                conn.execute(
                    f"DELETE FROM memory_records WHERE id IN ({placeholders})",
                    tuple(ids),
                )
            except Exception:
                with self._lock:
                    self._tag_names = cache_snapshot
                raise
        self._sync_memory_fts_batch_sync(
            upsert_ids=[new_memory.id],
            delete_ids=ids,
        )

        return new_memory

    async def process_feedback(
        self,
        useful_memory_ids: Optional[List[str]] = None,
        recalled_memory_ids: Optional[List[str]] = None,
        memory_actions: Optional[List[Dict[str, Any]]] = None,
        memory_scope: str = "public",
    ) -> List[BaseMemory]:
        resolved_scope = self._normalize_scope(memory_scope)
        created_memories: List[BaseMemory] = []

        useful_ids = [str(x).strip() for x in (useful_memory_ids or []) if str(x).strip()]
        recalled_ids = [str(x).strip() for x in (recalled_memory_ids or []) if str(x).strip()]
        if useful_ids:
            await self.reinforce_memories(useful_ids, delta=1)
        if recalled_ids:
            useful_set = set(useful_ids)
            useless_recalled = [mid for mid in recalled_ids if mid not in useful_set]
            if useless_recalled:
                await self.decay_recalled_but_useless(useless_recalled, delta=1)

        for action_data in (memory_actions or []):
            action = str(action_data.get("action", "") or "").strip().lower()
            memory_data = action_data.get("memory")
            if not isinstance(memory_data, dict):
                continue

            judgment = str(memory_data.get("judgment") or "").strip()
            reasoning = str(memory_data.get("reasoning") or "").strip()
            if not judgment:
                continue

            if action == "create":
                memory = await self.remember(
                    memory_type=str(memory_data.get("type") or "knowledge"),
                    judgment=judgment,
                    reasoning=reasoning,
                    tags=memory_data.get("tags") or [],
                    is_active=bool(memory_data.get("is_active", False)),
                    strength=memory_data.get("strength"),
                    memory_scope=resolved_scope,
                )
                created_memories.append(memory)
                continue

            if action not in {"merge", "updata"}:
                continue

            source_memory_ids = action_data.get("source_memory_ids", [])
            if not isinstance(source_memory_ids, list) or not source_memory_ids:
                continue

            merged = await asyncio.to_thread(
                self._merge_action_sync,
                source_memory_ids,
                memory_data,
                resolved_scope,
            )
            if merged:
                created_memories.append(merged)

        return created_memories

    def _merge_action_sync(
        self,
        source_memory_ids: List[str],
        memory_data: Dict[str, Any],
        resolved_scope: str,
    ) -> Optional[BaseMemory]:
        source_ids = list(
            dict.fromkeys(
                str(memory_id).strip()
                for memory_id in (source_memory_ids or [])
                if str(memory_id).strip()
            )
        )
        if not source_ids:
            return None

        memories = self._get_memories_by_ids_sync(source_ids)
        if not memories:
            return None

        non_public_scopes = {
            str(mem.memory_scope or "public").strip()
            for mem in memories
            if str(mem.memory_scope or "public").strip() != "public"
        }
        if len(non_public_scopes) > 1:
            raise ValidationError("禁止合并不同私有分类域的记忆")

        merged_scope = next(iter(non_public_scopes), resolved_scope)
        now = time.time()
        new_memory = BaseMemory(
            memory_type=self._to_memory_type(str(memory_data.get("type") or "knowledge")),
            judgment=str(memory_data.get("judgment") or "").strip(),
            reasoning=str(memory_data.get("reasoning") or "").strip(),
            tags=self._normalize_tags(memory_data.get("tags") or []),
            id=str(uuid.uuid4()),
            strength=sum(mem.strength for mem in memories),
            is_active=bool(memory_data.get("is_active", False)),
            created_at=now,
            memory_scope=merged_scope,
            useful_count=sum(int(getattr(mem, "useful_count", 0) or 0) for mem in memories),
            useful_score=max(float(getattr(mem, "useful_score", 0.0) or 0.0) for mem in memories),
            last_recalled_at=max(float(getattr(mem, "last_recalled_at", 0.0) or 0.0) for mem in memories),
        )

        ids = [mem.id for mem in memories]
        placeholders = ",".join(["?" for _ in ids])
        with self._lock:
            cache_snapshot = set(self._tag_names)
        with self._connect() as conn:
            try:
                conn.execute(
                    """
                    INSERT INTO memory_records(
                        id, memory_type, judgment, reasoning, strength, is_active,
                        useful_count, useful_score, last_recalled_at,
                        memory_scope, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        new_memory.id,
                        new_memory.memory_type.value,
                        new_memory.judgment,
                        new_memory.reasoning,
                        new_memory.strength,
                        1 if new_memory.is_active else 0,
                        new_memory.useful_count,
                        new_memory.useful_score,
                        new_memory.last_recalled_at,
                        new_memory.memory_scope,
                        new_memory.created_at,
                        now,
                    ),
                )
                self._upsert_tags_and_bind(conn, new_memory.id, new_memory.tags)
                conn.execute(
                    f"DELETE FROM memory_tag_rel WHERE memory_id IN ({placeholders})",
                    tuple(ids),
                )
                conn.execute(
                    f"DELETE FROM memory_records WHERE id IN ({placeholders})",
                    tuple(ids),
                )
            except Exception:
                with self._lock:
                    self._tag_names = cache_snapshot
                raise
        self._sync_memory_fts_batch_sync(
            upsert_ids=[new_memory.id],
            delete_ids=ids,
        )
        return new_memory

    def close(self) -> None:
        with self._lock:
            self._tag_names.clear()

    def shutdown(self) -> None:
        self.close()
